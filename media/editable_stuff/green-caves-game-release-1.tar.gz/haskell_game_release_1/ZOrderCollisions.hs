{-

Copyright 2011 Eli Dupree

This file is part of Eli Dupree's currently-unnamed experimental Haskell game.

This game is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This game is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this game.  If not, see <http://www.gnu.org/licenses/>.

-}

module ZOrderCollisions
( getAllIntersections
) where

import qualified Data.List as List
import qualified Data.Map as Map
import qualified Data.Set as Set
import qualified Data.Bits as Bits
import qualified ExactGeom as Geom
import qualified ZTree

powersOf2 :: [Integer]
powersOf2 = iterate (*2) 1

type ZBox = [Bool]



pairsFrom :: [a] -> [(a, a)]
pairsFrom [] = []
pairsFrom [x] = [] -- technically this is covered by the following line, but w/e
pairsFrom (x:xs) = foldl (\acc y -> (x, y):acc) (pairsFrom xs) xs

collectBoxOverlaps :: (Ord a) => [(ZBox, a)] -> [a] -> Set.Set (a, a)
collectBoxOverlaps [] _ = Set.empty
collectBoxOverlaps presentBoxes collectors =
  -- for each zbox, if it's "here", then add it as a collector and give it to the existing collectors.
  -- otherwise, pass it to a sub-box.
  let
    (boxesHere, boxes0, boxes1) = {-# SCC "1" #-} List.foldl' (\(h, b0, b1) stuff@(box, idx) -> case box of
      [] -> (stuff:h,b0,b1)
      False:tail -> (h,(tail, idx):b0,b1)
      True:tail -> (h,b0,(tail, idx):b1)) ([],[],[]) presentBoxes
    indicesHere = {-# SCC "2" #-} map snd boxesHere
    newCollectors = {-# SCC "3" #-} (indicesHere ++ collectors)
    pairsFromAbove = {-# SCC "4" #-} Set.fromList [(min c1 c2, max c1 c2) | c1 <- collectors, c2 <- indicesHere, c1 /= c2]
    pairsFromHere = Set.fromList $ map (\(a,b)->if a>b then (b,a) else (a,b)) $ pairsFrom indicesHere
    pairsFrom0 = {-# SCC "5" #-} collectBoxOverlaps boxes0 newCollectors
    pairsFrom1 = {-# SCC "6" #-} collectBoxOverlaps boxes1 newCollectors
    in {-# SCC "7" #-} Set.unions [pairsFromAbove, pairsFromHere, pairsFrom0, pairsFrom1]

shapeZBoxes :: (Int, Integer, Integer) -> Geom.Shape -> [ZBox]
shapeZBoxes (highestPower, minX, minY) shape = case Geom.shapeBounds shape of
  Geom.NowhereBounds -> []
  (Geom.BoundingBox absolutelx absolutehx absolutely absolutehy) -> let
    lx = absolutelx - minX
    hx = absolutehx - minX
    ly = absolutely - minY
    hy = absolutehy - minY
    width = hx + 1 - lx
    height = hy + 1 - ly
    maxDim = max width height
    Just firstRealBit = List.findIndex (>=maxDim) powersOf2
    {-collectBits :: Integer -> Integer -> Int -> ZBox
    collectBits x y bit
      | bit < firstRealBit = []
      | otherwise = {-# SCC "collectBits" #-} (Bits.testBit x bit):(Bits.testBit y bit):(collectBits x y (bit-1))
    in {-# SCC "nubCollectBits" #-} List.nub [collectBits lx ly highestPower,collectBits lx hy highestPower,collectBits hx hy highestPower,collectBits hx ly highestPower]-}
    collectBits :: (Integer, Integer) -> Int -> [Bool]
    collectBits (x, y) bit = {-# SCC "collectBits" #-} [(Bits.testBit x bit),(Bits.testBit y bit)]
    bitsList = [highestPower,(highestPower-1)..firstRealBit]
    in {-# SCC "nubCollectBits" #-} List.nub [concatMap (collectBits (lx, ly)) bitsList,concatMap (collectBits (lx, hy)) bitsList,concatMap (collectBits (hx, hy)) bitsList,concatMap (collectBits (hx, ly)) bitsList]


-- I think this function might give a number that ends up being greater by 1 than the needed value. I should rename BOTH these functions (we don't "need" a "power", we need a... bit index?) and fix them for whatever purpose they actually have.
highestPowerNeededForUnaligned :: Geom.Bounds -> Int
highestPowerNeededForUnaligned Geom.NowhereBounds = -1
highestPowerNeededForUnaligned (Geom.BoundingBox lx hx ly hy) = let maxb = max (hx + 1 - lx) (hy + 1 - ly) in case List.findIndex (>=maxb) powersOf2 of
  Nothing -> error "wtf"
  Just a -> a

highestPowerNeededForAligned :: Geom.Bounds -> Int
highestPowerNeededForAligned Geom.NowhereBounds = -1
highestPowerNeededForAligned (Geom.BoundingBox lx hx ly hy) = case List.findIndex (\n -> ((((lx `div` n) + 2) * n) > hx) && ((((ly `div` n) + 2) * n) > hy)) powersOf2 of
  Nothing -> error "wtf"
  Just a -> a

-- I made "aligned" because I have these wall tiles that always sit neatly in one z-box and don't intersect other walls. Without the alignment, I might be calling the intersect function for lots of adjacent pairs of them.
getAllIntersections :: (Ord a) => Bool -> Map.Map a Geom.Shape -> Set.Set (a, a)
getAllIntersections aligned shapesMap =
  -- Get the total bounds of everything, so that we can make z boxes.
  case Geom.shapeBounds . Geom.ShapeList $ Map.elems shapesMap of
    -- Nothing has any bounds? Ho ho ho. Nothing collides obviously.
    Geom.NowhereBounds -> Set.empty
    everywhereBounds@(Geom.BoundingBox lx hx ly hy) -> let
      --zBoxGenerationInfo = (highestPowerNeededFor everywhereBounds, lx, ly)
      zBoxGenerationInfo = case aligned of
        False -> (highestPowerNeededForUnaligned everywhereBounds, lx, ly)
        True -> let pow = highestPowerNeededForAligned everywhereBounds; powpow = (powersOf2 !! pow) in
          (pow, (lx `div` powpow) * powpow, ly `div` (powpow) * powpow)
      generateZBoxes = shapeZBoxes zBoxGenerationInfo
      zBoxList = concatMap (\(idx, shape) -> zip (generateZBoxes shape) (repeat idx)) $ Map.assocs shapesMap
      zBoxOverlaps = collectBoxOverlaps zBoxList []
      --zBoxOverlaps = snd . ZTree.zTreeAddBoundsesAndGetNewOverlaps ZTree.empty . Map.assocs $ Map.map Geom.shapeBounds shapesMap
      shapesActuallyIntersect (idx1, idx2) = Geom.shapesIntersect (shapesMap Map.! idx1) (shapesMap Map.! idx2)
      collisions = Set.filter shapesActuallyIntersect zBoxOverlaps
      in collisions
        {-case Set.toList collisions of
        [] -> collisions
        (this, that):_ -> error $ (show (shapesMap Map.! this)) ++ (show (shapesMap Map.! that))-}


