{-

Copyright 2011 Eli Dupree

This file is part of Eli Dupree's currently-unnamed experimental Haskell game.

This game is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This game is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this game.  If not, see <http://www.gnu.org/licenses/>.

-}

import qualified Graphics.Rendering.OpenGL as GL
import qualified Graphics.UI.SDL as SDL
import qualified Data.Map as Map
import qualified Data.Set as Set
import qualified Data.List as List
import qualified System.Random as Random
import qualified ExactGeom
import qualified ZOrderCollisions
import qualified ZTree

-- as per tauday.com
tau :: (Floating a) => a
tau = 2.0*pi

type ObjectIndex = Int

squareSubdivisions :: Integer
squareSubdivisions = 2^17

data Object = Hero {
  referenceLocation :: ExactGeom.Point       ,
  heroShape         :: ExactGeom.Shape       ,
  heroMovement      :: ExactGeom.Displacement,
  heroShootDelay    :: Int
} | Wall ExactGeom.Shape | Laser ExactGeom.Shape ExactGeom.Displacement deriving (Show)
objectNextAndTrajectory :: Object -> (Object, ExactGeom.Shape)
objectNextAndTrajectory h@Hero{ referenceLocation = p, heroShape = s, heroMovement = d } = (h {
    referenceLocation = ExactGeom.pointMovedBy p d,
    heroShape = ExactGeom.shapeMovedBy s d
  }, ExactGeom.shapeSweep s d)
objectNextAndTrajectory w@(Wall s) = (w, s)
objectNextAndTrajectory (Laser s d) = (Laser (ExactGeom.shapeMovedBy s d) d, ExactGeom.shapeSweep s d)

objectMotionIndependentTick :: Object -> Object
objectMotionIndependentTick h@Hero { heroShootDelay = s } = h { heroShootDelay = if s > 0 then (s - 1) else 0 }
objectMotionIndependentTick o = o

objectSurvivesDormancy :: Object -> Bool
objectSurvivesDormancy (Laser _ _) = False
objectSurvivesDormancy _ = True

objectShape :: Object -> ExactGeom.Shape
objectShape (Hero { heroShape = s }) = s
objectShape (Wall s) = s
objectShape (Laser s _) = s

objectCollisionResults :: Object -> [Object] -> (Maybe Object, [Object])
objectCollisionResults obj [] = (Just obj, [])
objectCollisionResults h@Hero{} others = if any (\c -> case c of (Wall _) -> True; _ -> False) others then (Just $ h { heroMovement = ExactGeom.Displacement 0 0 }, []) else (Just (fst . objectNextAndTrajectory $ h), [])
objectCollisionResults w@(Wall _) others = if any (\c -> case c of (Laser _ _) -> True; _ -> False) others then (Nothing, []) else (Just w, [])
objectCollisionResults l@(Laser _ _) others = if any (\c -> case c of (Wall _) -> True; _ -> False) others then (Nothing, []) else (Just (fst . objectNextAndTrajectory $ l), [])

tilesBox :: ExactGeom.Bounds -> Set.Set (Integer, Integer)
tilesBox ExactGeom.NowhereBounds = Set.empty
tilesBox (ExactGeom.BoundingBox lx hx ly hy) = Set.fromList [(x, y) | x <- [(lx `div` squareSubdivisions) .. (hx `div` squareSubdivisions)], y <- [(ly `div` squareSubdivisions) .. (hy `div` squareSubdivisions)]]


data GameState = GameState {
  gameHeroIndex      :: ObjectIndex               ,
  nextInsertIndex    :: ObjectIndex               ,
  activeObjectsMap   :: Map.Map ObjectIndex Object,
  dormantObjectsMap  :: Map.Map ObjectIndex Object,
  existentYetTiles   :: Set.Set (Integer, Integer),
  dormantObjectsTree :: ZTree.ZTree ObjectIndex   ,
  activeKeys         :: Set.Set SDL.SDLKey        ,
  --activeModifierKeys :: Set.Set SDL.Modifier      ,
  activeMouseButtons :: Set.Set SDL.MouseButton   ,
  mouseLocation      :: ExactGeom.Point
}

getHero :: GameState -> Maybe Object
getHero gs = Map.lookup (gameHeroIndex gs) (activeObjectsMap gs)
getHeroLoc :: GameState -> Maybe ExactGeom.Point
getHeroLoc gs = case getHero gs of
  Just (Hero { referenceLocation = p }) -> Just p
  _ -> Nothing
changeHero :: GameState -> (Object -> Object) -> GameState
changeHero gs func = gs { activeObjectsMap = Map.adjust func (gameHeroIndex gs) $ activeObjectsMap gs}

gamestateWithTileExistent :: Integer -> Integer -> GameState -> GameState
gamestateWithTileExistent x y gs@GameState{existentYetTiles = tiles} = if (x, y) `Set.member` tiles then gs else
  List.foldl' (flip gamestateAfterNewObjectInserted) gs { existentYetTiles = Set.insert (x, y) tiles } $ getInitialMapElementsBySquare x y

pairsFrom :: [a] -> [(a, a)]
pairsFrom [] = []
pairsFrom [x] = [] -- technically this is covered by the following line, but w/e
pairsFrom (x:xs) = foldl (\acc y -> (x, y):acc) (pairsFrom xs) xs

gamestateAfterTick :: GameState -> GameState
gamestateAfterTick initialGameState@GameState { activeObjectsMap = objects } = let
  objectsBeforeMoving = Map.map objectMotionIndependentTick objects
  objectNextsAndTrajectories = Map.map objectNextAndTrajectory objectsBeforeMoving
  --objectsOccupyingMap :: Map.Map (Integer, Integer) [(ObjectIndex, Object)]
  --objectsOccupyingMap = Map.fromListWith (++) (Map.foldlWithKey (\acc idx obj -> acc++[(sq, [(idx, obj)]) | sq <- Set.toList $ objectSquares obj]) [] objectNewPositions)
  --objectMaybeCollidingPairs = Map.fold (\objs acc -> pairsFrom objs ++ acc) [] objectsOccupyingMap
  --objectMaybeCollidingPairs = pairsFrom $ Map.assocs objectNewPositions
  --collisions = [(idx1, idx2) | ((idx1, obj1), (idx2, obj2)) <- objectMaybeCollidingPairs, objectsIntersect obj1 obj2]
  objectTrajectories = Map.map snd objectNextsAndTrajectories
  objectNextsIgnoringCollisions = Map.map fst objectNextsAndTrajectories

  collisions = ZOrderCollisions.getAllIntersections True objectTrajectories

  collisionsByIdx :: Map.Map ObjectIndex [ObjectIndex]
  collisionsByIdx = Set.fold (\(idx1, idx2) acc -> Map.insertWith (++) idx2 [idx1] $ Map.insertWith (++) idx1 [idx2] acc) Map.empty collisions
  
  collisionResults :: Map.Map ObjectIndex (Maybe Object, [Object])
  collisionResults = Map.mapWithKey (\idx idxs -> objectCollisionResults (objectsBeforeMoving Map.! idx) (map (objectsBeforeMoving Map.!) idxs)) collisionsByIdx
  
  objectNextsConsideringCollisions :: Map.Map ObjectIndex Object
  objectNextsConsideringCollisions = Map.foldlWithKey (\acc idx (maybeObj, _) -> case maybeObj of Nothing -> Map.delete idx acc; Just obj -> Map.insert idx obj acc) objectNextsIgnoringCollisions collisionResults

  gameStateWithObjectsMovedAndCollided = List.foldl' (flip gamestateAfterNewObjectInserted) initialGameState { activeObjectsMap = objectNextsConsideringCollisions } $ concatMap (snd . snd) (Map.assocs collisionResults)
  realNewGameState = case getHero gameStateWithObjectsMovedAndCollided of
    Just (Hero { referenceLocation = ExactGeom.Point x y, heroShootDelay = shootDelay }) -> let

      gameStateWithHeroAccelerated = changeHero gameStateWithObjectsMovedAndCollided (\h@Hero{ heroMovement = ExactGeom.Displacement x y } -> h { heroMovement = ExactGeom.Displacement (x
          + (if SDL.SDLK_LEFT  `Set.member` activeKeys initialGameState then negate (squareSubdivisions `div` 128) else 0)
          + (if SDL.SDLK_RIGHT `Set.member` activeKeys initialGameState then        (squareSubdivisions `div` 128) else 0)) 
                                          (y
          + (if SDL.SDLK_DOWN  `Set.member` activeKeys initialGameState then negate (squareSubdivisions `div` 128) else 0)
          + (if SDL.SDLK_UP    `Set.member` activeKeys initialGameState then        (squareSubdivisions `div` 128) else 0)) })

      activityBounds = ExactGeom.BoundingBox (x - 10*squareSubdivisions) (x + 10*squareSubdivisions) (y - 10*squareSubdivisions) (y + 10*squareSubdivisions)
      gameStateWithWallsAdded = Set.fold (uncurry gamestateWithTileExistent) gameStateWithHeroAccelerated $ tilesBox activityBounds
      gameStateWithEverythingAdded = if (shootDelay == 0) && (SDL.ButtonLeft `Set.member` activeMouseButtons initialGameState) then let
          ExactGeom.Point intdx intdy = mouseLocation initialGameState
          (dx, dy) = (fromIntegral intdx, fromIntegral intdy)
          mag = sqrt (dx*dx + dy*dy)
          (ndx, ndy) = (round $ dx * ((fromIntegral squareSubdivisions) / 3.0) / mag, round $ dy * ((fromIntegral squareSubdivisions) / 3.0) / mag)
          in
            changeHero (gamestateAfterNewObjectInserted (Laser (ExactGeom.ShapeSegment $ ExactGeom.LineSegment (ExactGeom.Point x y) (ExactGeom.Point (x+(ndx*2)) (y+(ndy*2)))) (ExactGeom.Displacement ndx ndy)) gameStateWithWallsAdded) (\h@Hero{} -> h { heroShootDelay = 4 })
        else gameStateWithWallsAdded

      objectShouldBeActive = ExactGeom.boundsOverlap activityBounds . ExactGeom.shapeBounds . objectShape

      splitByActivity (act, dorm) idx obj = if objectShouldBeActive obj then (Map.insert idx obj act, dorm) else (act, Map.insert idx obj dorm)
      (stillActive, becomingDormant) = Map.foldlWithKey splitByActivity (Map.empty, Map.empty) (activeObjectsMap gameStateWithEverythingAdded)
      maybeBecomingActiveIndices = map snd . Set.toList . snd $ ZTree.zTreeAddBoundsesAndGetNewOverlaps (dormantObjectsTree gameStateWithEverythingAdded) [(0, activityBounds)]
      survingBecomingDormant = Map.filter objectSurvivesDormancy becomingDormant

      becomingActive = List.foldl' (\acc idx -> let obj = (dormantObjectsMap gameStateWithEverythingAdded) Map.! idx in if objectShouldBeActive obj then Map.insert idx obj acc else acc) Map.empty maybeBecomingActiveIndices

      newDormantTree = fst $ ZTree.zTreeAddBoundsesAndGetNewOverlaps (ZTree.zTreeDeleteBoxes (dormantObjectsTree gameStateWithEverythingAdded) (Map.keys becomingActive)) (Map.assocs $ Map.map (ExactGeom.shapeBounds . objectShape) survingBecomingDormant)

      gameStateWithActivityAdjusted = gameStateWithEverythingAdded {
          activeObjectsMap = List.foldl' (flip $ uncurry Map.insert) stillActive (Map.assocs becomingActive),
          dormantObjectsMap = List.foldl' (flip Map.delete) (List.foldl' (flip $ uncurry Map.insert) (dormantObjectsMap gameStateWithEverythingAdded) (Map.assocs survingBecomingDormant)) (Map.keys becomingActive),
          dormantObjectsTree = newDormantTree
        }
      in gameStateWithActivityAdjusted
    _ -> gameStateWithObjectsMovedAndCollided
  in realNewGameState

screenToInternalX coord = (((fromIntegral coord) - 320) * (20*squareSubdivisions) + 320) `div` 640
screenToInternalY coord = ((320 - (fromIntegral coord)) * (20*squareSubdivisions) + 320) `div` 640

gamestateAfterNewObjectInserted :: Object -> GameState -> GameState
gamestateAfterNewObjectInserted obj gs = gs { activeObjectsMap = Map.insert (nextInsertIndex gs) obj (activeObjectsMap gs), nextInsertIndex = (nextInsertIndex gs) + 1 }

gamestateAfterEvents :: [SDL.Event] -> GameState -> GameState
gamestateAfterEvents events gs = List.foldl' apply gs events
  where
    apply :: GameState -> SDL.Event -> GameState
    apply gs (SDL.MouseButtonDown x y butt) = gs { activeMouseButtons = Set.insert butt $ activeMouseButtons gs }
    apply gs (SDL.MouseButtonUp x y butt) = gs { activeMouseButtons = Set.delete butt $ activeMouseButtons gs }
    apply gs (SDL.MouseMotion x y dx dy) = gs { mouseLocation = ExactGeom.Point (screenToInternalX x) (screenToInternalY y) }
    apply gs (SDL.KeyDown SDL.Keysym{SDL.symKey = key}) = gs { activeKeys = Set.insert key $ activeKeys gs }
    apply gs (SDL.KeyUp SDL.Keysym{SDL.symKey = key}) = gs { activeKeys = Set.delete key $ activeKeys gs }
    {-case getHeroLoc gs of
      Nothing -> gs
      Just (ExactGeom.Point hx hy) -> let
        (dx, dy) = (fromIntegral $ screenToInternalX x, fromIntegral $ screenToInternalY y)
        mag = sqrt (dx*dx + dy*dy)
        (ndx, ndy) = (round $ dx * ((fromIntegral squareSubdivisions) / 3.0) / mag, round $ dy * ((fromIntegral squareSubdivisions) / 3.0) / mag)
        in
          gamestateAfterNewObjectInserted (Laser (ExactGeom.ShapeSegment $ ExactGeom.LineSegment (ExactGeom.Point hx hy) (ExactGeom.Point (hx+(ndx*2)) (hy+(ndy*2)))) (ExactGeom.Displacement ndx ndy)) gs-}
    {-case key of
      SDL.SDLK_LEFT  -> changeHero gs (\(Hero p s (ExactGeom.Displacement x y)) -> Hero p s (ExactGeom.Displacement (x-(squareSubdivisions `div` 40)) y))
      SDL.SDLK_RIGHT -> changeHero gs (\(Hero p s (ExactGeom.Displacement x y)) -> Hero p s (ExactGeom.Displacement (x+(squareSubdivisions `div` 40)) y))
      SDL.SDLK_UP    -> changeHero gs (\(Hero p s (ExactGeom.Displacement x y)) -> Hero p s (ExactGeom.Displacement x (y+(squareSubdivisions `div` 40))))
      SDL.SDLK_DOWN  -> changeHero gs (\(Hero p s (ExactGeom.Displacement x y)) -> Hero p s (ExactGeom.Displacement x (y-(squareSubdivisions `div` 40))))
      _ -> gs-}
    apply gs _ = gs

drawPointVertex :: ExactGeom.Point -> IO ()
drawPointVertex (ExactGeom.Point x y) = GL.vertex (GL.Vertex3 (fromIntegral x) (fromIntegral y) 0 :: GL.Vertex3 GL.GLint)

drawShape :: ExactGeom.Shape -> IO ()
drawShape (ExactGeom.ShapePoint p) =
  GL.renderPrimitive GL.Points $ drawPointVertex p
drawShape (ExactGeom.ShapeSegment (ExactGeom.LineSegment e1 e2)) =
  GL.renderPrimitive GL.Lines $ do
    drawPointVertex e1
    drawPointVertex e2
drawShape (ExactGeom.ShapePoly (ExactGeom.Polygon points)) =
  GL.renderPrimitive GL.Polygon $ mapM_ drawPointVertex points
drawShape (ExactGeom.ShapeList shapes) = mapM_ drawShape shapes

drawBounds (ExactGeom.BoundingBox lx hx ly hy) = do
  GL.color (GL.Color4 1.0 0.0 0.0 0.3 :: GL.Color4 GL.GLfloat)
  GL.renderPrimitive GL.Polygon $ do
        drawPointVertex $ ExactGeom.Point lx ly
        drawPointVertex $ ExactGeom.Point lx hy
        drawPointVertex $ ExactGeom.Point hx hy
        drawPointVertex $ ExactGeom.Point hx ly

drawObject :: Object -> IO ()
drawObject object = do
  GL.color (GL.Color3 0.0 1.0 0.0 :: GL.Color3 GL.GLfloat)
  (drawShape . objectShape) object
  --mapM_ drawBounds $ ZTree.hack $ (ExactGeom.shapeBounds . objectShape) object
drawGamestate :: GameState -> IO ()
drawGamestate gs@GameState{ activeObjectsMap = objects } = do
  case getHeroLoc gs of
    Nothing -> return ()
    Just (ExactGeom.Point x y) -> do
      GL.loadIdentity
      GL.ortho (fromIntegral (x - 10*squareSubdivisions)) (fromIntegral (x + 10*squareSubdivisions)) (fromIntegral (y - 10*squareSubdivisions)) (fromIntegral (y + 10*squareSubdivisions)) (-1.0) 1.0
  mapM_ drawObject (Map.elems objects)
  {-case getHeroLoc gs of
    Nothing -> return ()
    Just (ExactGeom.Point x y) -> let
      activityBounds = ExactGeom.BoundingBox (x - 8*squareSubdivisions) (x + 8*squareSubdivisions) (y - 8*squareSubdivisions) (y + 8*squareSubdivisions)
      boxBoundses = ZTree.hack activityBounds
      in mapM_ drawBounds boxBoundses-}

box :: Integer -> Integer -> Integer -> Integer -> [ExactGeom.Point]
box x y w h = [
      (ExactGeom.Point  x     y   ),
      (ExactGeom.Point  x    (y+h)),
      (ExactGeom.Point (x+w) (y+h)),
      (ExactGeom.Point (x+w)  y   )
  ]

{-wallHere :: (Integer, Integer) -> (Bool, Random.StdGen)
wallHere (0, 0) = (False, Random.mkStdGen 13940)
wallHere (x, y) = Random.random $ snd . wallHere $ (case x `compare` 0 of
  EQ -> 0
  LT -> x + 1
  GT -> x - 1, case y `compare` 0 of
  EQ -> 0
  LT -> y + 1
  GT -> y - 1)-}

getInitialMapElementsBySquare :: Integer -> Integer -> [Object]
getInitialMapElementsBySquare x y = let
  lx = (x `mod` 20)
  ly = (y `mod` 20)
  squareWallHere = [Wall . ExactGeom.ShapePoly . ExactGeom.Polygon $ box (x*squareSubdivisions) (y*squareSubdivisions) (squareSubdivisions-1) (squareSubdivisions-1)]
  {-in if lx < 2 || ly < 2 || (lx^2 + ly^2) < 40 then
    []
  else squareWallHere-}
  {-in if lx < 2 || ly < 2 then
      []
    --else if ((Random.randoms (Random.mkStdGen $ fromIntegral ((x + (y*100000)) `mod` (2^16)))) :: [Bool]) !! 100 then squareWallHere else []
    else if fst . wallHere $ (x, y) then squareWallHere else []-}
  in if lx < 2 || ly < 2 then [] else squareWallHere

mainSDLGLDraw :: (IO a) -> (IO ())
mainSDLGLDraw commands = do
  GL.clear [GL.ColorBuffer]
  commands
  GL.flush
  SDL.glSwapBuffers

main = SDL.withInit [SDL.InitEverything] $ do
    SDL.setVideoMode 640 640 32 [SDL.OpenGL]
    GL.viewport GL.$= (GL.Position 0 0, GL.Size 640 640)
    GL.ortho (fromIntegral ((-10)*squareSubdivisions)) (fromIntegral (10*squareSubdivisions)) (fromIntegral ((-10)*squareSubdivisions)) (fromIntegral (10*squareSubdivisions)) (-1.0) 1.0
    GL.clearColor GL.$= (GL.Color4 0 0 0 0)
    GL.blend GL.$= GL.Enabled
    GL.blendFunc GL.$= (GL.SrcAlpha, GL.OneMinusSrcAlpha)
    screen <- SDL.getVideoSurface
    GL.clear [GL.ColorBuffer]
    GL.flush
    SDL.glSwapBuffers
    loop GameState { activeObjectsMap = Map.fromList[
        (1, Hero {
          referenceLocation = ExactGeom.Point (squareSubdivisions`div`2) (squareSubdivisions`div`2),
          heroShape = let sweetrad = fromIntegral (squareSubdivisions`div`3) in ExactGeom.ShapePoly . ExactGeom.Polygon $ 
            [ExactGeom.Point (round ((fromIntegral (squareSubdivisions`div`2)) + sweetrad*(cos th))) (round ((fromIntegral (squareSubdivisions`div`2)) + sweetrad*(sin th))) |
             th <- [(fromIntegral foo) * tau / 20.0 | foo <- [1..20]]],
          heroMovement = ExactGeom.Displacement 0 0,
          heroShootDelay = 0
          }) --,
        --(2, Object {velocity = Displacement 20 20, shapes=[Circle (Point 0 18000) 1000]}),
        --(3, Object {velocity = Displacement (-20) 20, shapes=[Circle (Point 5000 10000) 1000]})
      ],
      dormantObjectsMap = Map.empty,
      gameHeroIndex = 1,
      nextInsertIndex = 4,
      existentYetTiles = Set.empty,
      dormantObjectsTree = ZTree.empty,
      activeKeys = Set.empty,
      activeMouseButtons = Set.empty,
      mouseLocation = ExactGeom.Point 0 0 }
  where
    getEvents :: IO [SDL.Event] -> IO [SDL.Event]
    getEvents acc = do
      event <- SDL.pollEvent
      case event of
        SDL.NoEvent -> acc
        e -> do 
          acc2 <- acc
          getEvents $ return (e:acc2)
    loop gs = do
      mainSDLGLDraw (drawGamestate gs)
      SDL.delay 10
      events <- getEvents $ return []
      if SDL.Quit `elem` events then
        return ()
        else
        loop $ gamestateAfterTick $ gamestateAfterEvents events gs

