{-

Copyright 2011 Eli Dupree

This file is part of Eli Dupree's currently-unnamed experimental Haskell game.

This game is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This game is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this game.  If not, see <http://www.gnu.org/licenses/>.

-}

module ExactGeom
( Bounds (..)
, Displacement (..)
, Point (..)
, LineSegment (..)
, Polygon (..)
, Shape (..)
, boundsOverlap
, shapeMovedBy
, shapeBounds
, shapeSweep
, shapesIntersect
, pointMovedBy
) where

import qualified Data.List as List

data Clockwiseness = Clockwise | Counterclockwise | Collinear deriving (Show, Eq)
data Displacement = Displacement Integer Integer deriving (Show)
-- in "minx, maxx, miny, maxy" format
data Bounds = NowhereBounds | BoundingBox Integer Integer Integer Integer deriving (Show)

data Point = Point Integer Integer deriving (Show)
data LineSegment = LineSegment Point Point deriving (Show)

-- If you want to use shapeSweep, your polygon must not have lines that intersect (except at their endpoints).
data Polygon = Polygon [Point] deriving (Show)

-- ShapeNothing is technically equivalent to ShapeList [], but then again, there's already an uncountable infinity of equivalents of ShapeList [].
data Shape = ShapeNothing | ShapePoint Point | ShapeSegment LineSegment | ShapePoly Polygon | ShapeList [Shape] deriving (Show)

boundsOverlap :: Bounds -> Bounds -> Bool
boundsOverlap (BoundingBox lx hx ly hy) (BoundingBox lx2 hx2 ly2 hy2) = lx <= hx2 && lx2 <= hx && ly <= hy2 && ly2 <= hy
boundsOverlap _ _ = False

shapeMovedBy :: Shape -> Displacement -> Shape
shapeMovedBy  ShapeNothing                      d = ShapeNothing
shapeMovedBy (ShapePoint p)                     d = ShapePoint   $ p               `pointMovedBy` d
shapeMovedBy (ShapeSegment (LineSegment e1 e2)) d = ShapeSegment $ LineSegment (e1 `pointMovedBy` d) (e2 `pointMovedBy` d)
shapeMovedBy (ShapePoly (Polygon points))       d = ShapePoly    $ Polygon  $ map (`pointMovedBy` d) points
shapeMovedBy (ShapeList shapes)                 d = ShapeList    $            map (`shapeMovedBy` d) shapes

-- in "minx, maxx, miny, maxy" format
shapeBounds :: Shape -> Bounds
shapeBounds  ShapeNothing = NowhereBounds
shapeBounds (ShapePoint (Point x y)) = BoundingBox x x y y
shapeBounds (ShapeSegment (LineSegment (Point x1 y1) (Point x2 y2))) = BoundingBox (min x1 x2) (max x1 x2) (min y1 y2) (max y1 y2)
shapeBounds (ShapePoly (Polygon points)) = List.foldl' combineBounds NowhereBounds $ map (shapeBounds.ShapePoint) points
shapeBounds (ShapeList shapes) = List.foldl' combineBounds NowhereBounds $ map shapeBounds shapes

-- This is a slight misuse of "Displacement", I guess, since "Displacement" doesn't imply a continuous straight path.
shapeSweep :: Shape -> Displacement -> Shape
shapeSweep  ShapeNothing      d = ShapeNothing
shapeSweep (ShapeList shapes) d = ShapeList $ map (`shapeSweep` d) shapes
shapeSweep (ShapePoint p)     d = ShapeSegment $ LineSegment p (p `pointMovedBy` d)
shapeSweep (ShapePoly p)      d = let convexes = breakIntoConvexPolygons p in case convexes of
  [loner] -> ShapePoly $ convexPolygonSweep loner d
  more -> ShapeList $ map ShapePoly $ map (`convexPolygonSweep` d) more
shapeSweep (ShapeSegment l@(LineSegment e1 e2)) d = let
  moved_e1 = (e1 `pointMovedBy` d)
  moved_e2 = (e2 `pointMovedBy` d)
  stupidList = [e1, e2, moved_e2, moved_e1]
  in if (pointClockwisenessFromOrderedSegment l moved_e1) == Collinear then let
    stupidCompare (Point x1 y1) (Point x2 y2) = let xcmp = x1 `compare` x2 in if xcmp /= EQ then xcmp else y1 `compare` y2
    in ShapeSegment $ LineSegment (List.minimumBy stupidCompare stupidList) (List.maximumBy stupidCompare stupidList)
  else ShapePoly $ Polygon stupidList

shapesIntersect :: Shape -> Shape -> Bool
shapesIntersect  ShapeNothing other = False
shapesIntersect (ShapeList shapes) other = any (shapesIntersect other) shapes
shapesIntersect (ShapePoint (Point x1 y1)) (ShapePoint (Point x2 y2)) = x1 == x2 && y1 == y2
shapesIntersect (ShapePoint p) (ShapeSegment l) = (pointClockwisenessFromOrderedSegment l p) == Collinear && pointKnownToBeOnLineIntersectsLineSegment p l
shapesIntersect sl@(ShapeSegment (LineSegment e1 _)) sp@(ShapePoly p) = (shapesIntersect (ShapePoint e1) sp) || (any (shapesIntersect sl) $ map ShapeSegment (polygonSegments p))
shapesIntersect p1s@(ShapePoly p1@(Polygon points1)) p2s@(ShapePoly p2@(Polygon points2)) = or [shapesIntersect (ShapeSegment l1) (ShapeSegment l2) | l1 <- polygonSegments p1, l2 <- polygonSegments p2] || shapesIntersect (ShapePoint (points1 !! 0)) p2s || shapesIntersect (ShapePoint (points2 !! 0)) p1s
shapesIntersect (ShapeSegment l1@(LineSegment e11 e12)) (ShapeSegment l2@(LineSegment e21 e22)) = let
  clock11 = pointClockwisenessFromOrderedSegment l2 e11
  clock12 = pointClockwisenessFromOrderedSegment l2 e12
  clock21 = pointClockwisenessFromOrderedSegment l1 e21
  clock22 = pointClockwisenessFromOrderedSegment l1 e22
  in ((clock11 /= clock12) && (clock21 /= clock22)) ||
    (clock11 == Collinear && clock12 == Collinear && (
      pointKnownToBeOnLineIntersectsLineSegment e11 l2 ||
      pointKnownToBeOnLineIntersectsLineSegment e12 l2 ||
      pointKnownToBeOnLineIntersectsLineSegment e21 l1 ||
      pointKnownToBeOnLineIntersectsLineSegment e22 l1
    ))
shapesIntersect (ShapePoint p@(Point x y)) (ShapePoly poly) = 
-- Check how many times the edge of the polygon crosses the ray starting at the point and going to the right. If it's odd, the point is inside; otherwise, it's outside.
  foldr handle False $ polygonSegments poly
  where
    handle (LineSegment e1@(Point e1x e1y) e2@(Point e2x e2y)) acc
      -- Does it pass horizontally through the point? Obvious intersection
      | (e1ycmpy == EQ && e2ycmpy == EQ && e1xcmpx /= e2xcmpx) = True
      -- Does it remain completely above or completely below the point, or entirely on the left, or entirely on the right? Then it doesn't *cross* the ray, so ignore it
      | (e1ycmpy == e2ycmpy) = acc
      -- Does it pass directly through the point otherwise? Obvious intersection
      | (pointClockwiseness == Collinear) = True
      -- Does it pass to the left of the point? Then it doesn't cross the ray, so ignore it
      | (((e1ycmpy == EQ) && (e1xcmpx == LT))
          || ((e1ycmpy == LT) && (pointClockwiseness == Clockwise))
          || ((e1ycmpy == GT) && (pointClockwiseness == Counterclockwise))) = acc
      -- Does it clearly cross the ray? Count it
      | (e1ycmpy /= EQ && e2ycmpy /= EQ) = not acc
      -- Now we know that it either starts or ends on the ray. For any number of segments touching the ray in a row, we should count an odd number if they pass through and an even number if they come out again on the same side. I believe the following hack accomplishes this.
      | ((pointClockwiseness == Clockwise) {-arbitrarily; this works just as well if that one Clockwise is replaced with Counterclockwise-} == (e1ycmpy == EQ) {- arbitrarily; could have used e2 -}) = not acc
      | otherwise = acc
      where
        e1ycmpy = e1y `compare` y
        e2ycmpy = e2y `compare` y
        e1xcmpx = e1x `compare` x
        e2xcmpx = e2x `compare` x
        pointClockwiseness = pointClockwisenessFromOrderedSegment (LineSegment e1 e2) p
-- Generic "wrong order" case... I am brave! I risk infinite recursion if I have failed to implement a case!
shapesIntersect s1 s2 = shapesIntersect s2 s1



oppositeClockwiseness :: Clockwiseness -> Clockwiseness
oppositeClockwiseness Clockwise = Counterclockwise
oppositeClockwiseness Counterclockwise = Clockwise
oppositeClockwiseness Collinear = error "There's no such thing as the opposite of collinear!"

combineBounds :: Bounds -> Bounds -> Bounds
combineBounds NowhereBounds b = b
combineBounds b NowhereBounds = b
combineBounds (BoundingBox lx hx ly hy) (BoundingBox lx2 hx2 ly2 hy2) = (BoundingBox (min lx lx2) (max hx hx2) (min ly ly2) (max hy hy2))

isZeroDisplacement :: Displacement -> Bool
isZeroDisplacement (Displacement 0 0) = True
isZeroDisplacement _ = False

distanceSquared :: Point -> Point -> Integer
distanceSquared (Point x1 y1) (Point x2 y2) = (x1 - x2)^2 + (y1 - y2)^2

pointMovedBy :: Point -> Displacement -> Point
pointMovedBy (Point x y) (Displacement dx dy) = Point (x+dx) (y+dy)

pointClockwisenessFromOrderedSegment :: LineSegment -> Point -> Clockwiseness
pointClockwisenessFromOrderedSegment (LineSegment (Point rayBaseX rayBaseY) (Point rayNextX rayNextY)) (Point subjectX subjectY) =
  case 0 `compare` (((subjectY - rayBaseY) * (rayNextX - rayBaseX)) - ((rayNextY - rayBaseY) * (subjectX - rayBaseX))) of
    GT -> Clockwise
    LT -> Counterclockwise
    EQ -> Collinear

displacementRepeated :: Displacement -> Integer -> Displacement
displacementRepeated (Displacement x y) t = Displacement (x*t) (y*t)

pointKnownToBeOnLineIntersectsLineSegment :: Point -> LineSegment -> Bool
pointKnownToBeOnLineIntersectsLineSegment (Point x y) (LineSegment (Point e1x e1y) (Point e2x e2y)) = if e1x == e2x then (e1y `compare` y) /= (e2y `compare` y) else (e1x `compare` x) /= (e2x `compare` x)

polygonSegments :: Polygon -> [LineSegment]
polygonSegments (Polygon points) = let len = length points in [LineSegment (points !! idx) (points !! ((idx + 1) `mod` len)) | idx <- [0..len - 1]]

polygonClockwiseness :: Polygon -> Clockwiseness
polygonClockwiseness (Polygon points) = let
  len = length points
  Just (rightmostVertexIndex, rightmostVertex) = List.foldl' (\maybeBest this@(_, Point x _) -> case maybeBest of
    Nothing -> Just this
    best@(Just (_, Point bestx _)) -> if x > bestx then Just this else best) Nothing (zip [0..] points)
  mostRecentNonCollinearVertexClockwiseness (idx, vert) = let
    lastIdx = (idx - 1) `mod` len
    nextIdx = (idx + 1) `mod` len
    lastVertex = points !! lastIdx
    nextVertex = points !! nextIdx
    thisClockwiseness = pointClockwisenessFromOrderedSegment (LineSegment lastVertex vert) nextVertex
    in if thisClockwiseness /= Collinear then thisClockwiseness else mostRecentNonCollinearVertexClockwiseness (lastIdx, lastVertex)
  in mostRecentNonCollinearVertexClockwiseness (rightmostVertexIndex, rightmostVertex)

breakIntoConvexPolygons :: Polygon -> [Polygon]
breakIntoConvexPolygons plah = breakIntoConvexPolygonsWithKnownClockwiseness (polygonClockwiseness plah) plah
  where
   breakIntoConvexPolygonsWithKnownClockwiseness ourClockwiseness p@(Polygon points) = let
    len = length points
    antiOurClockwiseness = oppositeClockwiseness ourClockwiseness
    indexedVertices = (zip [0..] points)
    vertexClockwiseness (idx, vert) = let
      lastIdx = (idx - 1) `mod` len
      nextIdx = (idx + 1) `mod` len
      lastVertex = points !! lastIdx
      nextVertex = points !! nextIdx
      in pointClockwisenessFromOrderedSegment (LineSegment lastVertex vert) nextVertex
    firstConcaveVertex = List.find (\(idx, vert) -> vertexClockwiseness (idx, vert) == antiOurClockwiseness) indexedVertices
    in case firstConcaveVertex of
      -- no concave vertices? The polygon is set!
      Nothing -> [p]
      -- A concave vertex? Break it down...
      Just linearlyFirstConcaveVertexPair -> let
        recedeToEarlierConcaveVertex (idx, vert) = let
          lastIdx = (idx - 1) `mod` len
          lastVertex = points !! lastIdx
          in if vertexClockwiseness (lastIdx, lastVertex) == antiOurClockwiseness then recedeToEarlierConcaveVertex (lastIdx, lastVertex) else (idx, vert)
        (firstConcaveVertexIdx, firstConcaveVertex) = recedeToEarlierConcaveVertex linearlyFirstConcaveVertexPair
        lastEdge = LineSegment (points !! ((firstConcaveVertexIdx - 1) `mod` len)) firstConcaveVertex
        collect (idx, vert) = let
          lastIdx = (idx - 1) `mod` len
          lastVertex = points !! lastIdx
          in if pointClockwisenessFromOrderedSegment lastEdge lastVertex == antiOurClockwiseness then
            (idx, [vert])
            else let (finalIdx, list) = collect (lastIdx, lastVertex) in (finalIdx, vert:list)
        -- hmm... thisSide is oriented in the opposite direction
        (finalIdx, thisSide) = collect (firstConcaveVertexIdx, firstConcaveVertex)
        -- so we design it so that otherSide is, too, so that it's not HORRIBLY confusing
        collectOtherSide (idx, vert) = if idx == firstConcaveVertexIdx then [vert] else let
          lastIdx = (idx - 1) `mod` len
          lastVertex = points !! lastIdx
          in vert:collectOtherSide (lastIdx, lastVertex)
        otherSide = collectOtherSide (finalIdx, (points !! finalIdx))
        in (breakIntoConvexPolygonsWithKnownClockwiseness antiOurClockwiseness $ Polygon thisSide)++(breakIntoConvexPolygonsWithKnownClockwiseness antiOurClockwiseness $ Polygon otherSide)

convexPolygonSweep :: Polygon -> Displacement -> Polygon
convexPolygonSweep p@(Polygon points) d = if isZeroDisplacement d then p else Polygon $ concatMap newVerticesFor (zip [0..] points)
  where
    len = length points
    ourClockwiseness = polygonClockwiseness p
    antiOurClockwiseness = oppositeClockwiseness ourClockwiseness
    newVerticesFor (idx, vert) = let
      lastIdx = (idx - 1) `mod` len
      nextIdx = (idx + 1) `mod` len
      lastVert = points !! lastIdx
      nextVert = points !! nextIdx
      whereThisVertIsMovingTo = vert `pointMovedBy` d
      vertMovingVector = LineSegment vert whereThisVertIsMovingTo
      lastVertClock = pointClockwisenessFromOrderedSegment vertMovingVector lastVert
      nextVertClock = pointClockwisenessFromOrderedSegment vertMovingVector nextVert
      in if lastVertClock == Collinear && nextVertClock == Collinear then [] else
         if lastVertClock /= antiOurClockwiseness && nextVertClock /= ourClockwiseness then [vert] else
         if nextVertClock /= antiOurClockwiseness && lastVertClock /= ourClockwiseness then [whereThisVertIsMovingTo] else
            [vert, whereThisVertIsMovingTo]


