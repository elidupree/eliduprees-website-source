{-

Copyright 2011 Eli Dupree

This file is part of Eli Dupree's currently-unnamed experimental Haskell game.

This game is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This game is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this game.  If not, see <http://www.gnu.org/licenses/>.

-}

module ZTree
( ZTree
, empty
, zTreeAddBoundsesAndGetNewOverlaps
, zTreeDeleteBoxes
, hack
) where

import qualified Data.List as List
import qualified Data.Set as Set
import qualified Data.Map as Map
import qualified Data.Maybe as Maybe
import qualified Data.Array.Unboxed as Array
import qualified ExactGeom as Geom

-- anything above the upper bound is assumed to be all zeroes
-- anything below the lower bound is assumed to be everything
type ZBoxUnsigned = Array.UArray Int Bool
type ZTree a = Map.Map (Bool, Bool) (ZTreeNode a)

data ZTreeNode a = ZTreeNode {
    piecesHere :: Set.Set a,
    piecesHereOrBelow :: Set.Set a,
    nodeBit :: Int, -- This is the bit that this node *decides*. Anything *at* this node does *not* have this bit.
    zeroChild :: Maybe (ZTreeNode a),
    oneChild :: Maybe (ZTreeNode a)
  }

allBoolPairs = [(False, False),(False, True),(True, False),(True, True)]

--ZTree { piecesHere = Set.empty, piecesHereOrBelow = Set.empty, whichBit = -1, zeroChild = Nothing, oneChild = Nothing }
empty :: (Ord a) => ZTree a
empty = Map.empty

emptyNode :: (Ord a) => Int -> ZTreeNode a
emptyNode bit = ZTreeNode { piecesHere = Set.empty, piecesHereOrBelow = Set.empty, nodeBit = bit, zeroChild = Nothing, oneChild = Nothing }

zTreeAddBoundsesAndGetNewOverlaps :: (Ord a) => ZTree a -> [(a, Geom.Bounds)] -> (ZTree a, Set.Set (a, a))
zTreeAddBoundsesAndGetNewOverlaps tree boundses = zTreeAddBoxesAndGetNewOverlaps tree $ Map.fromListWith (++) $ concatMap
  (\(index, bounds) -> map (\(quadrant, unsignedBox) -> (quadrant, [(unsignedBox, index)])) (boundsToZBoxes bounds)) boundses

powersOf2 :: [Integer]
powersOf2 = iterate (*2) 1

hack :: Geom.Bounds -> [Geom.Bounds]
hack b = map zBoxToBounds $ boundsToZBoxes b

zBoxToBounds :: ((Bool, Bool), ZBoxUnsigned) -> Geom.Bounds
zBoxToBounds ((xNeg, yNeg), box) = let
  (lower, upper) = Array.bounds box
  xExplicit = sum [if box Array.! n then 2^(n`div`2) else 0 | n <- [upper,upper-2..lower]]
  yExplicit = sum [if box Array.! n then 2^(n`div`2) else 0 | n <- [upper-1,upper-3..lower]]
  xWidth = 2^(lower`div`2) - 1
  yWidth = 2^(lower`div`2) - 1
  in Geom.BoundingBox (if xNeg then (-(xExplicit + xWidth + 1)) else xExplicit)
                      (if xNeg then (-(xExplicit + 1)) else xExplicit + xWidth)
                      (if yNeg then (-(yExplicit + yWidth + 1)) else yExplicit)
                      (if yNeg then (-(yExplicit + 1)) else yExplicit + yWidth)

-- This could definitely be improved upon.
boundsToZBoxes :: Geom.Bounds -> [((Bool, Bool), ZBoxUnsigned)]
boundsToZBoxes Geom.NowhereBounds = []
boundsToZBoxes (Geom.BoundingBox lx hx ly hy) = let
  width = hx + 1 - lx
  height = hy + 1 - ly
  maxDim = max width height
  firstRealBit = let Just result = List.findIndex (>=maxDim) powersOf2 in result
  firstRealBitPow = (2^firstRealBit)
  splitX = lx + firstRealBitPow - (lx `mod` firstRealBitPow)
  splitY = ly + firstRealBitPow - (ly `mod` firstRealBitPow)
  collectBits :: (Integer, Integer) -> Int -> [Bool]
  collectBits (x, y) bit = {-# SCC "ZTreeCollectBits" #-} if bit < firstRealBit then [] else let
    (bit1, nextx) = if x >= (2^bit) then (True, x - (2^bit)) else (False, x)
    (bit2, nexty) = if y >= (2^bit) then (True, y - (2^bit)) else (False, y)
    in bit1:bit2:collectBits (nextx, nexty) (bit - 1)
  makeZBox x y = {-# SCC "ZTreeMakeZBox" #-} let
    (xBool, xUnsigned) = if x >= 0 then (False, x) else (True, (-x) - 1)
    (yBool, yUnsigned) = if y >= 0 then (False, y) else (True, (-y) - 1)
    highestPowerNeeded = let maxu = max xUnsigned yUnsigned; Just result = List.findIndex (> maxu) powersOf2 in max (result - 1) firstRealBit
    in ((xBool, yBool), Array.array (firstRealBit*2, highestPowerNeeded*2+1) (zip [highestPowerNeeded*2+1,highestPowerNeeded*2..firstRealBit*2] $ collectBits (xUnsigned, yUnsigned) highestPowerNeeded) :: Array.UArray Int Bool)
  in {-# SCC "ZTreeNubCollectBits" #-} List.nub [makeZBox lx ly, makeZBox lx hy, makeZBox hx ly, makeZBox hx hy]

zTreeAddBoxesAndGetNewOverlaps :: (Ord a) => ZTree a -> Map.Map (Bool, Bool) [(ZBoxUnsigned, a)] -> (ZTree a, Set.Set (a, a))
zTreeAddBoxesAndGetNewOverlaps tree boxes = (Map.map fst results, Set.unions $ map snd $ Map.elems results)
  where
    results = Map.mapMaybe fix $ Map.fromList (zip allBoolPairs allBoolPairs)
    --fix :: (Bool, Bool) -> Maybe (ZTreeNode a, Set.Set (a, a))
    fix bools = case (Map.lookup bools tree, Map.lookup bools boxes) of
      (Nothing, Nothing) -> Nothing
      (Just node, Nothing) -> Just (node, Set.empty)
      (Nothing, Just boxes) -> let maxInsertBit = maximum $ map (snd . Array.bounds . fst) boxes in
        Just (zTreeNodeAddBoxesAndGetNewOverlaps (emptyNode maxInsertBit) boxes)
      (Just node, Just boxes) -> let
        maxInsertBit = maximum $ map (snd . Array.bounds . fst) boxes
        result topNode = if (nodeBit topNode) < maxInsertBit then
          result $ ZTreeNode { piecesHere = Set.empty, piecesHereOrBelow = piecesHereOrBelow topNode, nodeBit = (nodeBit topNode) + 1, zeroChild = Just topNode, oneChild = Nothing }
          else Just (zTreeNodeAddBoxesAndGetNewOverlaps topNode boxes)
        in result node

-- this function assumes that the boxes all fit the node at higher bits.
zTreeNodeAddBoxesAndGetNewOverlaps :: (Ord a) => ZTreeNode a -> [(ZBoxUnsigned, a)] -> (ZTreeNode a, Set.Set (a, a))
zTreeNodeAddBoxesAndGetNewOverlaps node [] = (node, Set.empty)
zTreeNodeAddBoxesAndGetNewOverlaps node boxes = let
  bit = nodeBit node
  (hereBoxes, zeroBoxes, oneBoxes) = List.foldl' (\(h,b0,b1) p@(box,a) -> let bnds = Array.bounds box in if (fst bnds) > bit then (p:h,b0,b1) else if (((snd bnds) < bit) || (not (box Array.! bit))) then (h,p:b0,b1) else (h,b0,p:b1)) ([],[],[]) boxes

  (newZeroChild, zeroChildReportedOverlaps) = if null zeroBoxes then (zeroChild node, Set.empty) else case zeroChild node of
    Nothing -> let (a,b) = zTreeNodeAddBoxesAndGetNewOverlaps (emptyNode (bit - 1)) zeroBoxes in (Just a,b)
    Just child -> let (a,b) = zTreeNodeAddBoxesAndGetNewOverlaps child zeroBoxes in (Just a,b)
  (newOneChild, oneChildReportedOverlaps) = if null oneBoxes then (oneChild node, Set.empty) else case oneChild node of
    Nothing -> let (a,b) = zTreeNodeAddBoxesAndGetNewOverlaps (emptyNode (bit - 1)) oneBoxes in (Just a,b)
    Just child -> let (a,b) = zTreeNodeAddBoxesAndGetNewOverlaps child oneBoxes in (Just a,b)

  arrivingPieces = map snd hereBoxes
  oldPiecesHere = piecesHere node
  newPiecesHere = Set.union (Set.fromList arrivingPieces) oldPiecesHere
  oldPiecesHereOrBelow = (piecesHereOrBelow node)
  newPiecesHereOrBelow = Set.union (Set.fromList (map snd boxes)) oldPiecesHereOrBelow

  -- inefficient, perhaps?
  hereOverlaps = Set.fromList ([(min x y, max x y) | x <- arrivingPieces, y <- Set.toList oldPiecesHereOrBelow] ++ [(min x y, max x y) | x <- map snd boxes, y <- Set.toList newPiecesHere, x /= y])
  --hereOverlaps = Set.fromList ([(min x y, max x y) | x <- Set.toList newPiecesHereOrBelow, y <- Set.toList newPiecesHereOrBelow, x /= y])

  in (node {
      piecesHere = newPiecesHere,
      piecesHereOrBelow = newPiecesHereOrBelow,
      zeroChild = newZeroChild,
      oneChild = newOneChild
    }, Set.unions [hereOverlaps, zeroChildReportedOverlaps, oneChildReportedOverlaps])

zTreeDeleteBoxes :: (Ord a) => ZTree a -> [a] -> ZTree a
zTreeDeleteBoxes tree indices = Map.mapMaybe fix tree
  where
    --fix :: ZTreeNode a -> (Maybe (ZTreeNode a))
    fix topNode =
      if Set.null newPiecesHereOrBelow then Nothing else
      if (Set.null newPiecesHere) && (not (zeroChildHasNonDeletedElements && oneChildHasNonDeletedElements)) then
        if zeroChildHasNonDeletedElements then
             fix (Maybe.fromJust $ zeroChild topNode)
        else fix (Maybe.fromJust $  oneChild topNode)
      else Just $ zTreeNodeDeleteBoxes topNode indices
      where
        newPiecesHereOrBelow = (piecesHereOrBelow topNode) `deleteSmallListFromSet` indices
        newPiecesHere = (piecesHere topNode) `deleteSmallListFromSet` indices
        zeroChildHasNonDeletedElements = case zeroChild topNode of
          Nothing -> False
          Just child -> not . Set.null $ (piecesHereOrBelow child) `deleteSmallListFromSet` indices
        oneChildHasNonDeletedElements  = case  oneChild topNode of
          Nothing -> False
          Just child -> not . Set.null $ (piecesHereOrBelow child) `deleteSmallListFromSet` indices

zTreeNodeDeleteBoxes :: (Ord a) => ZTreeNode a -> [a] -> ZTreeNode a
zTreeNodeDeleteBoxes node indices = if null piecesRemovedFromHere then node else node {
      piecesHere = newPiecesHere,
      piecesHereOrBelow = newPiecesHereOrBelow,
      zeroChild = handleChild $ zeroChild node,  
      oneChild = handleChild $ oneChild node
    }
  where
    (newPiecesHereOrBelow, piecesRemovedFromHere) = (piecesHereOrBelow node) `deleteSmallListFromSetAndElemsRemoved` indices
    newPiecesHere = (piecesHere node) `deleteSmallListFromSet` indices
    --handleChild :: Maybe (ZTreeNode a) -> Maybe (ZTreeNode a)
    handleChild Nothing = Nothing
    handleChild (Just child) = let newChild = zTreeNodeDeleteBoxes child piecesRemovedFromHere in
      if Set.null $ piecesHereOrBelow newChild then Nothing else Just newChild

deleteSmallListFromSet :: (Ord a) => Set.Set a -> [a] -> Set.Set a
deleteSmallListFromSet = List.foldl' (flip Set.delete)
deleteSmallListFromSetAndElemsRemoved :: (Ord a) => Set.Set a -> [a] -> (Set.Set a, [a])
deleteSmallListFromSetAndElemsRemoved set list = List.foldl' (\acc@(setacc,listacc) idx -> if idx `Set.member` set then (Set.delete idx setacc, idx:listacc) else acc) (set,[]) list

