/*

Copyright 2011 Eli Dupree

This file is part of Eli Dupree's currently-unnamed experimental Haskell game, ported to C++.

This game is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This game is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this game.  If not, see <http://www.gnu.org/licenses/>.

*/

#ifndef CPPZTREE_ZTREE_HPP
#define CPPZTREE_ZTREE_HPP

#include <set>
#include <map>
#include <inttypes.h>
#include <boost/function.hpp>

typedef uint64_t ObjectIndex;

//void printbits(uint64_t wEver);

namespace ZTree {

//uint64_t convert_to_z_space(int64_t input) {
//  return uint64_t(input + (((int64_t)1)<<63));
//}

class ZBox {
public:
  ZBox(uint64_t bits, uint8_t num_low_bits_ignored):bits(bits & (~((1ULL<<num_low_bits_ignored)-1))),num_low_bits_ignored(num_low_bits_ignored) {}
  inline bool operator<(ZBox other)const {
    // DUPLICATE CODE *choke*
    const uint8_t max_bits_ignored = std::max(num_low_bits_ignored, other.num_low_bits_ignored);
    const uint64_t both_bits_mask = ~((1ULL << max_bits_ignored) - 1);
    const uint64_t our_shared_bits = (bits & both_bits_mask);
    const uint64_t their_shared_bits = (other.bits & both_bits_mask);
    if (our_shared_bits != their_shared_bits) return (our_shared_bits < their_shared_bits);
    if (other.num_low_bits_ignored > num_low_bits_ignored) return !(bits & (1ULL<<(other.num_low_bits_ignored - 1)));
    else if (other.num_low_bits_ignored < num_low_bits_ignored) return (other.bits & (1ULL<<(num_low_bits_ignored - 1)));
    else return false; // because we're equal
  }
  /*inline bool operator<=(ZBox other)const {
    // DUPLICATE CODE *choke*
    uint8_t max_bits_ignored = std::max(num_low_bits_ignored, other.num_low_bits_ignored);
    uint64_t both_bits_mask = ~((1ULL << max_bits_ignored) - 1);
    if ((bits & both_bits_mask) < (other.bits & both_bits_mask)) return true;
    if (other.num_low_bits_ignored > num_low_bits_ignored) return !(bits & (1ULL<<(other.num_low_bits_ignored - 1)));
    else if (other.num_low_bits_ignored < num_low_bits_ignored) return (other.bits & (1ULL<<(num_low_bits_ignored - 1)));
    else return true; // because we're equal
  }
  inline bool operator>(ZBox other)const {
    return !(*this <= other);
  }
  inline bool operator>=(ZBox other)const {
    return !(*this < other);
  }
  inline bool operator==(ZBox other)const {
    return (num_low_bits_ignored == other.num_low_bits_ignored) && (bits == other.bits); // this works because we assume that the ignored bits are actually zero
  }
  inline bool operator!=(ZBox other)const {
    return !(*this == other);
  }*/
  // these work because we assume that the ignored bits are actually zero
  ZBox lower_bound()const { return ZBox(bits,                             0); }
  ZBox upper_bound()const { return ZBox(bits + (1ULL<<num_low_bits_ignored), 0); }
  //TODO make these private again and come up with a better solution
//private:
  //uint64_t bits_with_low_bits_zeroed_out() { return (bits & (~((1<<num_low_bits_ignored)-1))) }
  //uint64_t bits_with_low_bits_oned_out() { return (bits | ((1<<num_low_bits_ignored)-1)) }
  uint64_t bits;
  uint8_t num_low_bits_ignored;
};

class ZTree {
public:
  ZTree(){}
  void insertBox(ObjectIndex idx, ZBox box);
  void deleteObject(ObjectIndex idx);
  void getBoxOverlaps(ZBox box, boost::function<void (ObjectIndex)> callback)const;
  //void drawlol();
private:
  std::multimap<ZBox,ObjectIndex> boxesToObjects;
  std::multimap<ObjectIndex,ZBox> objectsToBoxes;
};

}

#endif

