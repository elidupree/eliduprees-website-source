/*

Copyright 2011 Eli Dupree

This file is part of Eli Dupree's currently-unnamed experimental Haskell game, ported to C++.

This game is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This game is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this game.  If not, see <http://www.gnu.org/licenses/>.

*/

#include <iostream>
#include <map>
#include <cmath>

#include "SDL.h"
#include "GL/gl.h"
#include "GL/glu.h"

#include "ZGeom.hpp"

// refer to tauday.com
const double tau = 2*M_PI;

// we are currently relying on the fact that squareSubdivisions is a power of 2
const int squareShift = 10;
const int64_t squareSubdivisions = (1<<squareShift);

const int screen_pixel_width = 640;
const int screen_pixel_height = 640;
const int64_t screen_internal_width = squareSubdivisions*20;
const int64_t screen_internal_height = squareSubdivisions*20;
const int64_t max_cave_radius_in_tiles = 10;

const bool draw_zboxes = false;
const bool draw_sweeps = false;

enum objectType { HERO, LASER, WALL };
struct Object {
  Object(objectType type, ExactGeom::Shape shape):type(type),shape(shape),movement(0,0),stoppedByCollision(false),killedByCollision(false){
    const ExactGeom::Bounds bounds = shape.bounds();
    location = ExactGeom::Point((bounds.lx + bounds.hx)/2, (bounds.ly + bounds.hy)/2);
    if (type == LASER) {
      const ExactGeom::LineSegment foo = shape.getSegments()[0];
      movement = ExactGeom::Displacement((foo.e2.x - foo.e1.x)/2, (foo.e2.y - foo.e1.y)/2);
    }
  }
  objectType type;
  ExactGeom::Point location;
  ExactGeom::Shape shape;
  ExactGeom::Displacement movement;
  bool stoppedByCollision;
  bool killedByCollision;
  int shootDelay;
};

typedef std::map<ObjectIndex, Object>::iterator ObjectRef;

void handle_collision_onesided(Object &obj, Object const& other) {
  if ((obj.type == HERO) && (other.type == WALL)) {
    obj.stoppedByCollision = true;
  }
  if ((obj.type == LASER) && (other.type == WALL)) {
    obj.killedByCollision = true;
  }
  if ((obj.type == WALL) && (other.type == LASER)) {
    obj.killedByCollision = true;
  }
}

int64_t internalCoordToTileCoord(int64_t internal) { return internal >> squareShift; }
int64_t tileCoordToMinInternalCoord(int64_t tile) { return tile * squareSubdivisions; }
int64_t tileCoordToMaxInternalCoord(int64_t tile) { return tile * squareSubdivisions + squareSubdivisions - 1; }

struct Tile {
  int64_t x, y;
  Tile(int64_t x, int64_t y):x(x),y(y){}
  bool operator<(Tile const& other)const {
    if (x != other.x) return x < other.x;
    return y < other.y;
  }
};
struct CaveInfo {
  bool any_cave_here;
  int64_t radius;
};

struct CaveGenerator {
  CaveGenerator(){}
  std::map<Tile, CaveInfo> calculatedCaveCenters;
  std::vector<Object> get_cave_features_at(Tile loc) {
    std::vector<Object> results;
    for (int x = loc.x - max_cave_radius_in_tiles; x <= loc.x + max_cave_radius_in_tiles; ++x) {
      for (int y = loc.y - max_cave_radius_in_tiles; y <= loc.y + max_cave_radius_in_tiles; ++y) {
        CaveInfo infoHere = get_cave_info_at(Tile(x, y));
        if (infoHere.any_cave_here && ((x - loc.x)*(x - loc.x) + (y - loc.y)*(y - loc.y))*squareSubdivisions*squareSubdivisions <= infoHere.radius*infoHere.radius) {
          return results;
        }
      }
    }
    const int64_t minx = tileCoordToMinInternalCoord(loc.x);
    const int64_t maxx = tileCoordToMaxInternalCoord(loc.x);
    const int64_t miny = tileCoordToMinInternalCoord(loc.y);
    const int64_t maxy = tileCoordToMaxInternalCoord(loc.y);
    ExactGeom::Polygon wallPoly;
    wallPoly.points.push_back(ExactGeom::Point(minx, miny));
    wallPoly.points.push_back(ExactGeom::Point(minx, maxy));
    wallPoly.points.push_back(ExactGeom::Point(maxx, maxy));
    wallPoly.points.push_back(ExactGeom::Point(maxx, miny));
    results.push_back(Object(WALL, ExactGeom::Shape(wallPoly)));
    return results;
  }
  CaveInfo get_cave_info_at(Tile loc) {
    std::map<Tile, CaveInfo>::const_iterator alreadyCalculated = calculatedCaveCenters.find(loc);
    if (alreadyCalculated != calculatedCaveCenters.end()) {
      return alreadyCalculated->second;
    }
    else {
      CaveInfo new_info;
      new_info.any_cave_here = (rand() & 255) == 0;
      if (new_info.any_cave_here) {
        new_info.radius = squareSubdivisions*2 + (rand() % (squareSubdivisions * 8));
      }
      calculatedCaveCenters.insert(std::make_pair(loc, new_info));
      return new_info;
    }
  }
};

struct GameState {
  ObjectIndex gameHeroIndex;
  ObjectIndex nextInsertIndex;
  std::map<ObjectIndex, Object> objectsMap;
  std::set<ObjectIndex> activeObjects;
  ZTree::ZTree objectsTree;
  CaveGenerator caveGen;
  std::set<Tile> alreadyComputedCaveTiles;

  GameState():gameHeroIndex(1),nextInsertIndex(1){
    ExactGeom::Polygon heroShape;
    for (int i = 0; i < 20; ++i) {
      double theta = tau * ((double)i) / 20.0;
      heroShape.points.push_back(ExactGeom::Point((int64_t)(std::cos(theta) * squareSubdivisions / 3), (int64_t)(std::sin(theta) * squareSubdivisions / 3)));
    }
    insertNewObject(Object(HERO, ExactGeom::Shape(heroShape)));
  }

  void insertNewObject(Object o) {
    ZGeom::insertShape(objectsTree, nextInsertIndex, o.shape);
    objectsMap.insert(std::make_pair(nextInsertIndex, o));
    if (o.type != WALL) activeObjects.insert(nextInsertIndex);
    ++nextInsertIndex;
  }
  void deleteExistingObject(ObjectIndex i) {
    objectsTree.deleteObject(i);
    activeObjects.erase(i);
    objectsMap.erase(objectsMap.find(i));
  }

  std::set<ObjectIndex> objectsNearHero(int64_t distance, bool get_walls, bool drawlol = false) {
    ExactGeom::Point heroLoc = objectsMap.find(gameHeroIndex)->second.location;

    // stupid. this should be some sort of polygon. TODO
    ExactGeom::Shape activityShape(ExactGeom::LineSegment(ExactGeom::Point(heroLoc.x - distance, heroLoc.y - distance), ExactGeom::Point(heroLoc.x + distance, heroLoc.y + distance)));
    ExactGeom::Bounds activityBounds = activityShape.bounds();
    std::set<std::pair<ObjectIndex, ObjectIndex> > maybeActiveObjects;
    ZGeom::getOverlapsOfShape(objectsTree, 0, activityShape, maybeActiveObjects);
//    objectsTree.drawlol();
    //std::cerr << maybeActiveObjects.size() <<"..\n";
if (drawlol && draw_zboxes) {
// TODO TODO fix this duplicate code. It's a duplicate with the draw-object-bounds code in draw(). These could easily be abstracted into a function, "draw_object_bounds_and_zboxes" or whatever
      glColor3f(1.0,0.0,0.0);
      std::vector<ExactGeom::Bounds> zBoxBoundses = ZGeom::shapeZBoxBoundses(activityShape);
      zBoxBoundses.push_back(activityShape.bounds());
      for (std::vector<ExactGeom::Bounds>::const_iterator j = zBoxBoundses.begin(); j != zBoxBoundses.end(); ++j) {
        //std::cerr << "haha " << j->lx << "-" << j->hx << " .. " << j->ly << "-" << j->hy << "\n";
        glBegin(GL_LINE_LOOP);
          glVertex2f(j->lx, j->ly);
          glVertex2f(j->lx, j->hy);
          glVertex2f(j->hx, j->hy);
          glVertex2f(j->hx, j->ly);
        glEnd();
      }
}
    //std::cerr << "ww";
    std::set<ObjectIndex> results;
    for (std::set<std::pair<ObjectIndex, ObjectIndex> >::const_iterator i = maybeActiveObjects.begin(); i != maybeActiveObjects.end(); ++i) {
    //std::cerr << "haha";
      ObjectIndex idx = i->second;
      ObjectRef obj = objectsMap.find(idx);
      // stupid. should be intersecting with the activityShape. TODO
      if ((get_walls || obj->second.type != WALL) && ExactGeom::boundsOverlap(activityBounds, obj->second.shape.bounds()))
        results.insert(idx);
    }
    return results;
  }
  
  void tick() {
    ObjectRef hero = objectsMap.find(gameHeroIndex);

    //std::set<ObjectIndex> objectsInActiveArea = objectsNearHero(squareSubdivisions*12, false);
    std::set<std::pair<ObjectIndex, ObjectIndex> > potentialCollisions;
    for (std::set<ObjectIndex>::const_iterator i = activeObjects.begin(); i != activeObjects.end(); ++i) {
      objectsTree.deleteObject(*i);
    }
    for (std::set<ObjectIndex>::const_iterator i = activeObjects.begin(); i != activeObjects.end(); ++i) {
      ObjectRef obj = objectsMap.find(*i);
      ZGeom::insertAndGetOverlapsOfShape(objectsTree, *i, obj->second.shape.sweep(obj->second.movement), potentialCollisions);
      obj->second.stoppedByCollision = false;
    }
    for (std::set<ObjectIndex>::const_iterator i = activeObjects.begin(); i != activeObjects.end(); ++i) {
      objectsTree.deleteObject(*i);
    }
    
    std::multimap<ObjectIndex, ObjectIndex> collisionsByObject;
    for (std::set<std::pair<ObjectIndex, ObjectIndex> >::const_iterator i = potentialCollisions.begin(); i != potentialCollisions.end(); ++i) {
      ObjectRef obj1 = objectsMap.find(i->first);
      ObjectRef obj2 = objectsMap.find(i->second);
      if (obj1->second.shape.sweep(obj1->second.movement).intersects(obj2->second.shape.sweep(obj2->second.movement))) {
        collisionsByObject.insert(std::make_pair(i->first, i->second));
        collisionsByObject.insert(std::make_pair(i->second, i->first));
        handle_collision_onesided(obj1->second, obj2->second);
        handle_collision_onesided(obj2->second, obj1->second);
      }
    }
    for (std::multimap<ObjectIndex, ObjectIndex>::const_iterator i = collisionsByObject.begin(); i != collisionsByObject.end(); ++i) {
      ObjectRef obj1 = objectsMap.find(i->first);
      ObjectRef obj2 = objectsMap.find(i->second);
      handle_collision_onesided(obj1->second, obj2->second);
    }
    
    for (std::multimap<ObjectIndex, ObjectIndex>::const_iterator i = collisionsByObject.begin(); i != collisionsByObject.end(); ++i) {
      ObjectRef obj = objectsMap.find(i->first);
      if (obj != objectsMap.end() && obj->second.killedByCollision) {
        deleteExistingObject(i->first);
      }
      ObjectRef obj2 = objectsMap.find(i->second);
      if (obj2 != objectsMap.end() && obj2->second.killedByCollision) {
        deleteExistingObject(i->second);
      }
    }

    for (std::set<ObjectIndex>::const_iterator i = activeObjects.begin(); i != activeObjects.end(); ++i) {
      ObjectRef obj = objectsMap.find(*i);
      if (obj != objectsMap.end()) {
        if (obj->second.stoppedByCollision) {
          obj->second.movement.dx = 0;
          obj->second.movement.dy = 0;
        }
        else {
          obj->second.location += obj->second.movement;
          obj->second.shape.moveBy(obj->second.movement);
        }
        ZGeom::insertShape(objectsTree, *i, obj->second.shape);
      }
    }

    if (hero->second.shootDelay > 0) --hero->second.shootDelay;
    if (hero->second.shootDelay == 0) {
      int mouse_screen_x,mouse_screen_y;
      Uint8 buttons_active = SDL_GetMouseState(&mouse_screen_x, &mouse_screen_y);
      int64_t mouse_game_x = ((int64_t)(mouse_screen_x - (screen_pixel_width / 2))) * screen_internal_width / screen_pixel_width;
      int64_t mouse_game_y = ((int64_t)((screen_pixel_height / 2) - mouse_screen_y)) * screen_internal_height / screen_pixel_height;
      int64_t mag = std::sqrt((mouse_game_x * mouse_game_x) + (mouse_game_y * mouse_game_y));
      if (buttons_active & SDL_BUTTON_LMASK) {
        insertNewObject(Object(LASER, ExactGeom::Shape(ExactGeom::LineSegment(hero->second.location, ExactGeom::Point(hero->second.location.x + ((mouse_game_x * squareSubdivisions / (3 * mag)) * 2), hero->second.location.y + ((mouse_game_y * squareSubdivisions / (3 * mag)) * 2))))));
        hero->second.shootDelay = 4;
      }
    }
    Uint8 *keys_active = SDL_GetKeyState(NULL);
    hero->second.movement.dx += ((keys_active[SDLK_RIGHT] || keys_active[SDLK_d]) ? (squareSubdivisions/128) : 0) - ((keys_active[SDLK_LEFT] || keys_active[SDLK_a]) ? (squareSubdivisions/128) : 0);
    hero->second.movement.dy += ((keys_active[SDLK_UP] || keys_active[SDLK_w]) ? (squareSubdivisions/128) : 0) - ((keys_active[SDLK_DOWN] || keys_active[SDLK_s]) ? (squareSubdivisions/128) : 0);

    for (std::set<ObjectIndex>::const_iterator i = activeObjects.begin(); i != activeObjects.end(); ++i) {
      ObjectRef obj = objectsMap.find(*i);
      // The hero can see up to (a bunch of) tiles, so we need to fill in those walls. Other things just need to create the walls they're going to run into. We assume that non-hero objects don't move terribly fast. TODO: Compute this in a more robust way.
      const int64_t wall_box_dist = std::max(((obj->second.type == HERO) ? ((std::max(screen_internal_width, screen_internal_height) + 1) / 2) : 0), squareSubdivisions * 3);
      const int64_t wall_box_minx = internalCoordToTileCoord(obj->second.location.x - wall_box_dist);
      const int64_t wall_box_maxx = internalCoordToTileCoord(obj->second.location.x + wall_box_dist);
      const int64_t wall_box_miny = internalCoordToTileCoord(obj->second.location.y - wall_box_dist);
      const int64_t wall_box_maxy = internalCoordToTileCoord(obj->second.location.y + wall_box_dist);
      for (int64_t x = wall_box_minx; x <= wall_box_maxx; ++x) {
        for (int64_t y = wall_box_miny; y <= wall_box_maxy; ++y) {
          const Tile tile(x, y);
          if (alreadyComputedCaveTiles.find(tile) == alreadyComputedCaveTiles.end()) {
            alreadyComputedCaveTiles.insert(tile);
            std::vector<Object> new_walls = caveGen.get_cave_features_at(tile);
            for (std::vector<Object>::const_iterator i = new_walls.begin(); i != new_walls.end(); ++i) {
              insertNewObject(*i);
            }
          }
        }
      }
    }
  }

  void draw() {
    //std::cerr << "draw\n";
    std::set<ObjectIndex> drawnObjects = objectsNearHero(squareSubdivisions*10, true, true);
    ExactGeom::Point heroLoc = objectsMap.find(gameHeroIndex)->second.location;
//std::cerr << heroLoc.x << "," <<heroLoc.y << "\n";
    glLoadIdentity();
    gluOrtho2D(heroLoc.x - (screen_internal_width / 2), heroLoc.x + (screen_internal_width / 2), heroLoc.y - (screen_internal_height / 2), heroLoc.y + (screen_internal_height / 2));

//    objectsTree.drawlol();

    for (std::set<ObjectIndex>::const_iterator i = drawnObjects.begin(); i != drawnObjects.end(); ++i) {
      ObjectRef obj = objectsMap.find(*i);
    //for (ObjectRef obj = objectsMap.begin(); obj != objectsMap.end(); ++obj) {
   // std::cerr << "lol\n";
      ExactGeom::Shape shapeToDraw(draw_sweeps ? obj->second.shape.sweep(obj->second.movement) : obj->second.shape);
      std::vector<ExactGeom::Point> const& points = shapeToDraw.getPoints();
      std::vector<ExactGeom::LineSegment> const& segments = shapeToDraw.getSegments();
      std::vector<ExactGeom::Polygon> const& polygons = shapeToDraw.getPolygons();
      glColor3f(0.0,1.0,0.0);
      if (!points.empty()) {
        glBegin(GL_POINTS);
        for (std::vector<ExactGeom::Point>::const_iterator j = points.begin(); j != points.end(); ++j) {
          glVertex2f(j->x, j->y);
        }
        glEnd();
      }
      if (!segments.empty()) {
        glBegin(GL_LINES);
        for (std::vector<ExactGeom::LineSegment>::const_iterator j = segments.begin(); j != segments.end(); ++j) {
          glVertex2f(j->e1.x, j->e1.y);
          glVertex2f(j->e2.x, j->e2.y);
        }
        glEnd();
      }
      if (!polygons.empty()) {
        for (std::vector<ExactGeom::Polygon>::const_iterator j = polygons.begin(); j != polygons.end(); ++j) {
          glBegin(GL_POLYGON);
          for (std::vector<ExactGeom::Point>::const_iterator k = j->points.begin(); k != j->points.end(); ++k) {
            glVertex2f(k->x, k->y);
          }
          glEnd();
          // hack - fix the edges. TODO find a better way to handle this.
          glBegin(GL_LINE_LOOP);
          for (std::vector<ExactGeom::Point>::const_iterator k = j->points.begin(); k != j->points.end(); ++k) {
            glVertex2f(k->x, k->y);
          }
          glEnd();
        }
      }
      if (draw_zboxes) {
        glColor3f(1.0,0.0,0.0);
        std::vector<ExactGeom::Bounds> zBoxBoundses = ZGeom::shapeZBoxBoundses(shapeToDraw);
        zBoxBoundses.push_back(shapeToDraw.bounds());
        for (std::vector<ExactGeom::Bounds>::const_iterator j = zBoxBoundses.begin(); j != zBoxBoundses.end(); ++j) {
          //std::cerr << "haha " << j->lx << "-" << j->hx << " .. " << j->ly << "-" << j->hy << "\n";
          glBegin(GL_LINE_LOOP);
            glVertex2f(j->lx, j->ly);
            glVertex2f(j->lx, j->hy);
            glVertex2f(j->hx, j->hy);
            glVertex2f(j->hx, j->ly);
          glEnd();
        }
      }
    }
  }
};
/*
namespace ZTree {
  void ZTree::drawlol() {
    std::cerr << "!!! "<< boxesToObjects.size() <<"\n";
    //for (peekIter i = boxesToObjects.begin(); i != boxesToObjects.end(); ++i) {
    //  printbits(i->first.bits);
    //}
  }
}
*/

int main(int argc, char **argv) {
  if (SDL_Init(SDL_INIT_VIDEO) != 0) {
    std::cerr << "SDL_Init(SDL_INIT_VIDEO) failed: " << SDL_GetError() << "\n";
    return 1;
  }
  atexit(SDL_Quit);
  
  SDL_Surface *screen = SDL_SetVideoMode(screen_pixel_width, screen_pixel_height, 32, SDL_OPENGL);
  if (screen == NULL) {
    std::cerr << "SDL_SetVideoMode failed: " << SDL_GetError() << "\n";
    return 1;
  }

  glClearColor(0.0,0.0,0.0,0.0);
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

  srand(time(NULL));
  GameState gs;

  bool done = false;
  while ( !done ) {
    SDL_Event event;
    while ( SDL_PollEvent (&event) ) {
      switch (event.type) {
        case SDL_MOUSEMOTION:
          break;
        case SDL_MOUSEBUTTONDOWN:
          break;
        case SDL_KEYDOWN:
          if(event.key.keysym.sym != SDLK_ESCAPE) break;
        case SDL_QUIT:
          done = 1;
          break;
        default:
          break;
      }
    }
		
    //nowTicks = SDL_GetTicks();
    //double time = (nowTicks - thenTicks) / 1000.0;
    //thenTicks = nowTicks;

    SDL_Delay(10);
    gs.tick();

    glClear(GL_COLOR_BUFFER_BIT);
		
    gs.draw();

    glFinish();	
    SDL_GL_SwapBuffers();
  }
  return 0;
}

