/*

Copyright 2011 Eli Dupree

This file is part of Eli Dupree's currently-unnamed experimental Haskell game, ported to C++.

This game is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This game is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this game.  If not, see <http://www.gnu.org/licenses/>.

*/

#include "ExactGeom.hpp"
#include <cassert>

namespace ExactGeom {

// Note: We assume a right-handed system.
enum Clockwiseness { UNDEFINED, CLOCKWISE, COUNTERCLOCKWISE, COLLINEAR };

Clockwiseness oppositeClockwiseness(Clockwiseness input) {
  if (input == CLOCKWISE) return COUNTERCLOCKWISE;
  if (input == COUNTERCLOCKWISE) return CLOCKWISE;
  assert(false);
}

bool boundsOverlap(Bounds b1, Bounds b2) {
  return b1.is_anywhere && b2.is_anywhere && b1.lx <= b2.hx && b2.lx <= b1.hx && b1.ly <= b2.hy && b2.ly <= b1.hy;
}

void combineBounds(Bounds &b1, Bounds b2) {
  if (!b2.is_anywhere) return;
  if (!b1.is_anywhere) b1 = b2;
  if (b2.lx < b1.lx) b1.lx = b2.lx;
  if (b2.hx > b1.hx) b1.hx = b2.hx;
  if (b2.ly < b1.ly) b1.ly = b2.ly;
  if (b2.hy > b1.hy) b1.hy = b2.hy;
}

void Shape::moveBy(Displacement d) {
  for (std::vector<Point>::iterator i = points.begin(); i != points.end(); ++i) {
    (*i) += d;
  }
  for (std::vector<LineSegment>::iterator i = segments.begin(); i != segments.end(); ++i) {
    i->e1 += d;
    i->e2 += d;
  }
  for (std::vector<Polygon>::iterator j = polygons.begin(); j != polygons.end(); ++j) {
    for (std::vector<Point>::iterator i = j->points.begin(); i != j->points.end(); ++i) {
      (*i) += d;
    }
  }
  if (boundsCacheValid && boundsCache.is_anywhere) {
    boundsCache.lx += d.dx;
    boundsCache.hx += d.dx;
    boundsCache.ly += d.dy;
    boundsCache.hy += d.dy;
    // left valid!
  }
}

Bounds Shape::bounds()const {
  if (boundsCacheValid) return boundsCache;
  boundsCache = Bounds();
  for (std::vector<Point>::const_iterator i = points.begin(); i != points.end(); ++i) {
    combineBounds(boundsCache, Bounds(true, i->x, i->x, i->y, i->y));
  }
  for (std::vector<LineSegment>::const_iterator i = segments.begin(); i != segments.end(); ++i) {
    combineBounds(boundsCache, Bounds(true, i->e1.x, i->e1.x, i->e1.y, i->e1.y));
    combineBounds(boundsCache, Bounds(true, i->e2.x, i->e2.x, i->e2.y, i->e2.y));
  }
  for (std::vector<Polygon>::const_iterator j = polygons.begin(); j != polygons.end(); ++j) {
    for (std::vector<Point>::const_iterator i = j->points.begin(); i != j->points.end(); ++i) {
      combineBounds(boundsCache, Bounds(true, i->x, i->x, i->y, i->y));
    }
  }
  boundsCacheValid = true;
  return boundsCache;
}

int sign(int64_t input) {
  if (input > 0) return 1;
  if (input < 0) return -1;
  return 0;
}

Clockwiseness pointClockwisenessFromOrderedSegment(LineSegment ray, Point p) {
  const int64_t temp = (((p.y - ray.e1.y) * (ray.e2.x - ray.e1.x)) - ((ray.e2.y - ray.e1.y) * (p.x - ray.e1.x)));
  if (temp > 0) return COUNTERCLOCKWISE;
  if (temp < 0) return CLOCKWISE;
  return COLLINEAR;
}
bool pointKnownToBeOnLineIntersectsLineSegment(Point p, LineSegment l) {
  if (l.e1.x == l.e2.x) {
    return (sign(p.y - l.e1.y) != sign(p.y - l.e2.y));
  }
  else {
    return (sign(p.x - l.e1.x) != sign(p.x - l.e2.x));
  }
}

bool nonshape_intersects(Point p1, Point p2) {
  return p1.x == p2.x && p1.y == p2.y;
}
bool nonshape_intersects(Point p, LineSegment l) {
  return pointClockwisenessFromOrderedSegment(l, p) == COLLINEAR && pointKnownToBeOnLineIntersectsLineSegment(p, l);
}
bool nonshape_intersects(LineSegment l1,LineSegment l2) {
  const Clockwiseness clock11 = pointClockwisenessFromOrderedSegment(l2, l1.e1);
  const Clockwiseness clock12 = pointClockwisenessFromOrderedSegment(l2, l1.e2);
  if (clock11 == COLLINEAR && clock12 == COLLINEAR) {
    return (pointKnownToBeOnLineIntersectsLineSegment(l1.e1, l2)
         || pointKnownToBeOnLineIntersectsLineSegment(l1.e2, l2)
         || pointKnownToBeOnLineIntersectsLineSegment(l2.e1, l1)
         || pointKnownToBeOnLineIntersectsLineSegment(l2.e2, l1));
  }
  if (clock11 == clock12) return false;
  const Clockwiseness clock21 = pointClockwisenessFromOrderedSegment(l1, l2.e1);
  const Clockwiseness clock22 = pointClockwisenessFromOrderedSegment(l1, l2.e2);
  return (clock21 != clock22);
}
bool nonshape_intersects(Point subject,Polygon const& p) {
  // Check how many times the edge of the polygon crosses the ray starting at the point and going to the right. If it's odd, the point is inside; otherwise, it's outside.
  bool accumulator = false;
  for (int i = 0; i < (int)p.points.size(); ++i) {
    LineSegment seg(p.points[i],p.points[(i+1)%p.points.size()]);
    const int e1ycmpy = sign(seg.e1.y - subject.y);
    const int e2ycmpy = sign(seg.e2.y - subject.y);
    const int e1xcmpx = sign(seg.e1.x - subject.x);
    const int e2xcmpx = sign(seg.e2.x - subject.x);
    // Does it pass horizontally through the point? Obvious intersection
    if (e1ycmpy == 0 && e2ycmpy == 0 && e1xcmpx != e2xcmpx) return true;
    // Does it remain completely above or completely below the point, or entirely horizontal on the left, or entirely on the right? Then it doesn't *cross* the ray, so ignore it
    if (e1ycmpy == e2ycmpy) continue;
    // Does it pass directly through the point otherwise? Obvious intersection
    const Clockwiseness pointClockwiseness = pointClockwisenessFromOrderedSegment(seg, subject);
    if (pointClockwiseness == COLLINEAR) return true;
    // Does it pass to the left of the point? Then it doesn't cross the ray, so ignore it
    if (    (e1ycmpy == 0 && e1xcmpx < 0)
         || (e1ycmpy <  0 && pointClockwiseness == CLOCKWISE)
         || (e1ycmpy >  0 && pointClockwiseness == COUNTERCLOCKWISE)) continue;
    // Does it clearly cross the ray? Count it
    if (e1ycmpy != 0 && e2ycmpy != 0) accumulator = !accumulator;
    // Now we know that it either starts or ends on the ray. For any number of segments touching the ray in a row, we should count an odd number if they pass through and an even number if they come out again on the same side. I believe the following hack accomplishes this.
    if ((pointClockwiseness == CLOCKWISE) /*arbitrarily; this works just as well if that one Clockwise is replaced with Counterclockwise*/ == (e1ycmpy == 0) /* arbitrarily; could have used e2 */) accumulator = !accumulator;
    // Otherwise ignore it (pretend this line was there, though not being there makes no differece)
    // else continue;
  }
  return accumulator;
}
bool nonshape_intersects(LineSegment l,Polygon const& p) {
  if (nonshape_intersects(l.e1, p)) return true;
  for (int i = 0; i < (int)p.points.size(); ++i) {
    if (nonshape_intersects(l, LineSegment(p.points[i],p.points[(i+1)%p.points.size()]))) return true;
  }
  return false;
}
bool nonshape_intersects(Polygon const& p1, Polygon const& p2) {
  for (int i = 0; i < (int)p1.points.size(); ++i) { for (int j = 0; j < (int)p2.points.size(); ++j) {
    if (nonshape_intersects(
           LineSegment(p1.points[i],p1.points[(i+1)%p1.points.size()]), 
           LineSegment(p2.points[j],p2.points[(j+1)%p2.points.size()]))) return true;
  }}
  if (nonshape_intersects(p1.points[0], p2)) return true;
  if (nonshape_intersects(p2.points[0], p1)) return true;
  return false;
}


bool Shape::intersects(Shape const& other)const {
  if (!boundsOverlap(bounds(), other.bounds())) return false;
  for (std::vector<Point>::const_iterator i = points.begin(); i != points.end(); ++i) {
    for (std::vector<Point>::const_iterator j = other.points.begin(); j != other.points.end(); ++j) {
      if (nonshape_intersects(*i, *j)) return true;
    }
    for (std::vector<LineSegment>::const_iterator j = other.segments.begin(); j != other.segments.end(); ++j) {
      if (nonshape_intersects(*i, *j)) return true;
    }
    for (std::vector<Polygon>::const_iterator j = other.polygons.begin(); j != other.polygons.end(); ++j) {
      if (nonshape_intersects(*i, *j)) return true;
    }
  }
  for (std::vector<LineSegment>::const_iterator i = segments.begin(); i != segments.end(); ++i) {
    for (std::vector<Point>::const_iterator j = other.points.begin(); j != other.points.end(); ++j) {
      if (nonshape_intersects(*j, *i)) return true;
    }
    for (std::vector<LineSegment>::const_iterator j = other.segments.begin(); j != other.segments.end(); ++j) {
      if (nonshape_intersects(*i, *j)) return true;
    }
    for (std::vector<Polygon>::const_iterator j = other.polygons.begin(); j != other.polygons.end(); ++j) {
      if (nonshape_intersects(*i, *j)) return true;
    }
  }
  for (std::vector<Polygon>::const_iterator i = polygons.begin(); i != polygons.end(); ++i) {
    for (std::vector<Point>::const_iterator j = other.points.begin(); j != other.points.end(); ++j) {
      if (nonshape_intersects(*j, *i)) return true;
    }
    for (std::vector<LineSegment>::const_iterator j = other.segments.begin(); j != other.segments.end(); ++j) {
      if (nonshape_intersects(*j, *i)) return true;
    }
    for (std::vector<Polygon>::const_iterator j = other.polygons.begin(); j != other.polygons.end(); ++j) {
      if (nonshape_intersects(*i, *j)) return true;
    }
  }
  return false;
}

Clockwiseness vertexClockwiseness(Polygon const& p, int idx) {
  const int lastIdx = (idx + p.points.size() - 1) % p.points.size();
  const int nextIdx = (idx + 1) % p.points.size();
  return pointClockwisenessFromOrderedSegment(LineSegment(p.points[lastIdx], p.points[idx]), p.points[nextIdx]);
}

Clockwiseness polygonClockwiseness(Polygon const& p) {
  int64_t best;
  int rightmost_vertex_idx;
  for (int i = 0; i < (int)p.points.size(); ++i) {
    if (i == 0 || p.points[i].x > best) {
      rightmost_vertex_idx = i;
      best = p.points[i].x;
    }
  }
  while (true) {
    const Clockwiseness clock = vertexClockwiseness(p, rightmost_vertex_idx);
    if (clock != COLLINEAR) return clock;
    rightmost_vertex_idx = (rightmost_vertex_idx + 1) % p.points.size();
  }
}

void breakIntoConvexPolygons(Polygon const& p, std::vector<Polygon> &output, Clockwiseness ourClockwiseness = UNDEFINED) {
  if (ourClockwiseness == UNDEFINED) {
    ourClockwiseness = polygonClockwiseness(p);
  }
  const Clockwiseness antiOurClockwiseness = oppositeClockwiseness(ourClockwiseness);
  int last_concave_vertex = -1;
  for (int i = p.points.size() - 1; i >= 0; --i) {
    if (vertexClockwiseness(p, i) == antiOurClockwiseness) {
      last_concave_vertex = i;
      break;
    }
  }
  if (last_concave_vertex == -1) {
    // no concave vertices? The polygon is set!
    output.push_back(p);
    return;
  }

  // Move back until we have a _last_ concave vertex in a row.
  while (true) {
    const int nextIdx = (last_concave_vertex + 1) % p.points.size();
    if (vertexClockwiseness(p, nextIdx) == antiOurClockwiseness) {
      last_concave_vertex = nextIdx;
    }
    else break;
  }

  // Bite off a convex piece.
  Polygon newConvex;
  int counter_vertex = last_concave_vertex;
  newConvex.points.push_back(p.points[counter_vertex]);
  counter_vertex = (counter_vertex + 1) % p.points.size();
  while (true) {
    newConvex.points.push_back(p.points[counter_vertex]);
    int next_vertex = (counter_vertex + 1) % p.points.size();
    if (pointClockwisenessFromOrderedSegment(LineSegment(p.points[last_concave_vertex], p.points[counter_vertex]), p.points[next_vertex]) != ourClockwiseness) break;
    counter_vertex = next_vertex;
  }
  output.push_back(newConvex);

  // Collect the rest.
  Polygon remaining;
  while (true) {
    remaining.points.push_back(p.points[counter_vertex]);
    if (counter_vertex == last_concave_vertex) break;
    counter_vertex = (counter_vertex + 1) % p.points.size();
  }

  // Handle the rest.
  breakIntoConvexPolygons(remaining, output, ourClockwiseness);
}


Shape Shape::sweep(Displacement d)const {
  if (d.dx == 0 && d.dy == 0) return Shape(*this);

  Shape result;
  for (std::vector<Point>::const_iterator i = points.begin(); i != points.end(); ++i) {
    result.segments.push_back(LineSegment(*i, *i + d));
  }
  for (std::vector<LineSegment>::const_iterator i = segments.begin(); i != segments.end(); ++i) {
    const Point moved_e1 = i->e1 + d;
    const Point moved_e2 = i->e2 + d;
    if (pointClockwisenessFromOrderedSegment(*i, moved_e1) == COLLINEAR) {
      if (d.dx != 0) {
        if ((moved_e1.x > i->e1.x) == (i->e2.x > i->e1.x)) {
          result.segments.push_back(LineSegment(i->e1, moved_e2));
        }
        else {
          result.segments.push_back(LineSegment(moved_e1, i->e2));
        }
      }
      else {
        if ((moved_e1.y > i->e1.y) == (i->e2.y > i->e1.y)) {
          result.segments.push_back(LineSegment(i->e1, moved_e2));
        }
        else {
          result.segments.push_back(LineSegment(moved_e1, i->e2));
        }
      }
    }
    else {
      Polygon linesweep;
      linesweep.points.push_back(i->e1);
      linesweep.points.push_back(i->e2);
      linesweep.points.push_back(moved_e2);
      linesweep.points.push_back(moved_e1);
      result.polygons.push_back(linesweep);
    }
  }
  for (std::vector<Polygon>::const_iterator i = polygons.begin(); i != polygons.end(); ++i) {
    std::vector<Polygon> convexes;
    breakIntoConvexPolygons(*i, convexes);
    for (std::vector<Polygon>::const_iterator j = convexes.begin(); j != convexes.end(); ++j) {
      const Clockwiseness ourClockwiseness = polygonClockwiseness(*j);
      const Clockwiseness antiOurClockwiseness = oppositeClockwiseness(ourClockwiseness);
      Polygon partialSweep;
      for (int vert1 = 0; vert1 < (int)j->points.size(); ++vert1) {
        const int vert2 = (vert1 + 1) % j->points.size();
        const int vert3 = (vert1 + 2) % j->points.size();
        const Point whereVert2Is = j->points[vert2];
        const Point whereVert2IsGoing = whereVert2Is + d;
        const LineSegment vert2MovingVector(whereVert2Is, whereVert2IsGoing);
        const Clockwiseness lastVertClock = pointClockwisenessFromOrderedSegment(vert2MovingVector, j->points[vert1]);
        const Clockwiseness nextVertClock = pointClockwisenessFromOrderedSegment(vert2MovingVector, j->points[vert3]);
        if (lastVertClock == COLLINEAR && nextVertClock == COLLINEAR) continue;
        else if (lastVertClock != antiOurClockwiseness && nextVertClock != ourClockwiseness) {
          partialSweep.points.push_back(whereVert2Is);
        }
        else if (nextVertClock != antiOurClockwiseness && lastVertClock != ourClockwiseness) {
          partialSweep.points.push_back(whereVert2IsGoing);
        }
        else if (lastVertClock == ourClockwiseness) { // && (nextVertClock == ourClockwiseness)
          partialSweep.points.push_back(whereVert2Is);
          partialSweep.points.push_back(whereVert2IsGoing);
        }
        else { // (lastVertClock == antiOurClockwiseness) && (nextVertClock == antiOurClockwiseness)
          partialSweep.points.push_back(whereVert2IsGoing);
          partialSweep.points.push_back(whereVert2Is);
        }
      }
      result.polygons.push_back(partialSweep);
    }
  }
  return result;
}

}

