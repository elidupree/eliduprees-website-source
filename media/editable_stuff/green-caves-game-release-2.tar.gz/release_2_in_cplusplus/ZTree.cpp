/*

Copyright 2011 Eli Dupree

This file is part of Eli Dupree's currently-unnamed experimental Haskell game, ported to C++.

This game is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This game is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this game.  If not, see <http://www.gnu.org/licenses/>.

*/

#include "ZTree.hpp"
#include <iostream>
#include <cassert>


/*void printbits(uint64_t wEver) {
  for (int i = 63; i >= 0; --i) {
    std::cerr << !!(wEver & (1ULL << i));
  }
  std::cerr << "\n";
}*/

namespace ZTree {

void ZTree::insertBox(ObjectIndex idx, ZBox box) {
  boxesToObjects.insert(std::make_pair(box, idx));
  objectsToBoxes.insert(std::make_pair(idx, box));
//std::cerr << "EREIRJIEJVEJIE";
    //std::cerr << "!!! "<< boxesToObjects.size() <<"\n";
}
void ZTree::deleteObject(ObjectIndex idx) {
  //std::cerr << "ffffffffffffffffffffff";
  std::pair<std::multimap<ObjectIndex,ZBox>::iterator, std::multimap<ObjectIndex,ZBox>::iterator> bounds = objectsToBoxes.equal_range(idx);
  for (std::multimap<ObjectIndex,ZBox>::iterator i = bounds.first; i != bounds.second; )
  {
    std::pair<std::multimap<ZBox,ObjectIndex>::iterator, std::multimap<ZBox,ObjectIndex>::iterator> bounds2 = boxesToObjects.equal_range(i->second);
    for (std::multimap<ZBox,ObjectIndex>::iterator j = bounds2.first; j != bounds2.second; ) {
      if (j->second == idx) boxesToObjects.erase(j++);
      else ++j;
    }
    objectsToBoxes.erase(i++);
  }
}


void ZTree::getBoxOverlaps(ZBox box, boost::function<void (ObjectIndex)> callback)const {
  ZBox box_lower_bound = box.lower_bound();
  ZBox box_upper_bound = box.upper_bound();
  assert(box_lower_bound < box_upper_bound);
  std::multimap<ZBox,ObjectIndex>::const_iterator lower_bound = boxesToObjects.lower_bound(box_lower_bound);
  std::multimap<ZBox,ObjectIndex>::const_iterator upper_bound = boxesToObjects.lower_bound(box_upper_bound);
  //printbits(box.lower_bound().bits);
  //printbits(box.upper_bound().bits);
  //printbits(lower_bound->first.bits);
  //printbits(upper_bound->first.bits);
  //std::cerr << (lower_bound != boxesToObjects.end()) << (upper_bound != boxesToObjects.end()) << (lower_bound != upper_bound) << "\n";
  for (std::multimap<ZBox,ObjectIndex>::const_iterator i = lower_bound; i != upper_bound; ++i) {
    callback(i->second);
  }
  // the following is inefficient, which is why we should use a binary tree (pseudo radix tree!) instead of a set!
  ZBox upwards_walking_box = box;
  while (true) {
    upwards_walking_box = ZBox(upwards_walking_box.bits, upwards_walking_box.num_low_bits_ignored + 1);
    //std::cerr << upwards_walking_box.num_low_bits_ignored << "\n";
    if (upwards_walking_box.num_low_bits_ignored > 64) break;
    std::pair<std::multimap<ZBox,ObjectIndex>::const_iterator, std::multimap<ZBox,ObjectIndex>::const_iterator> bounds = boxesToObjects.equal_range(upwards_walking_box);
    for (std::multimap<ZBox,ObjectIndex>::const_iterator j = bounds.first; j != bounds.second; ++j) {
      callback(j->second);
    }
  }
}

}


