/*

Copyright 2011 Eli Dupree

This file is part of Eli Dupree's currently-unnamed experimental Haskell game, ported to C++.

This game is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This game is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this game.  If not, see <http://www.gnu.org/licenses/>.

*/

#include "ZGeom.hpp"
#include <iostream>

namespace ZGeom {

const int ZFactor = 1; // we divide by this when making the boxes. Increase it if you're having trouble with out-of-bounds objects... decrease it if it's forcing the smallest-sized z-boxes to be unreasonably bigger than they need to be

struct setInsertFunc {
  setInsertFunc(ObjectIndex idx, std::set<std::pair<ObjectIndex, ObjectIndex> > *overlapsCollector):idx(idx),overlapsCollector(overlapsCollector){}
  ObjectIndex idx;
  std::set<std::pair<ObjectIndex, ObjectIndex> > *overlapsCollector;
  void operator()(ObjectIndex idx2) {
    if (idx < idx2)
      overlapsCollector->insert(std::make_pair(idx, idx2));
    if (idx2 < idx)
      overlapsCollector->insert(std::make_pair(idx2, idx));
    // If they're the same, that's not really an overlap now is it?
    // if (idx == idx2)
    //   do nothing lol;
  } 
};

struct MaybeInsertMaybeGetCallback {
  MaybeInsertMaybeGetCallback(
    ZTree::ZTree *tree,
    ObjectIndex idx,
    bool insert,
    std::set<std::pair<ObjectIndex, ObjectIndex> > *overlapsCollector):tree(tree),idx(idx),insert(insert),overlapsCollector(overlapsCollector){}
  ZTree::ZTree *tree;
  ObjectIndex idx;
  bool insert;
  std::set<std::pair<ObjectIndex, ObjectIndex> > *overlapsCollector;
  void operator()(ZTree::ZBox box) {
    if (overlapsCollector) {
      tree->getBoxOverlaps(box, setInsertFunc(idx, overlapsCollector));
    }
    if (insert) tree->insertBox(idx, box);
  }
};

ZTree::ZBox makeZBox(uint32_t x, uint32_t y, int bits_ignored) {
  uint64_t result_bits = 0;
  //std::cerr << x << "," << y << "\n";
  for (int i = 63; i >= bits_ignored; --i) {
    int halfi = i / 2;
    if (i % 2) {
      result_bits |= (((uint64_t)(x & (1 << halfi))) << (i - halfi));
      //if (x & (1 << halfi)) std::cerr << "found x bit (" << i << "," << halfi << "," << (((uint64_t)(x & (1 << halfi))) << (i - halfi)) << ")\n";
    }
    else {
      result_bits |= (((uint64_t)(y & (1 << halfi))) << (i - halfi));
      //if (y & (1 << halfi)) std::cerr << "found y bit (" << i << "," << halfi << "," << (((uint64_t)(y & (1 << halfi))) << (i - halfi)) << ")\n";
    }
  }
  return ZTree::ZBox(result_bits, bits_ignored);
}

int lowest_shift_atleast(uint32_t input) {
  for (int i = 0; i < 32; ++i) {
    if ((((uint32_t)1) << i) >= input) return i;
  }
  return 32;
}

template <class Callback> void generateZBoxes(ExactGeom::Shape shape, Callback callback) {
  // Currently, we ignore the actual shape and use just the bounds. This is speed-efficient as long as the shape isn't long-and-thin or two-things-in-separate-places or anything. Perhaps this could be refined somehow.
  const ExactGeom::Bounds bounds = shape.bounds();
  if (!bounds.is_anywhere) return;

  int64_t plx = bounds.lx / ZFactor;
  int64_t phx = bounds.hx / ZFactor;
  int64_t ply = bounds.ly / ZFactor;
  int64_t phy = bounds.hy / ZFactor;

  if (plx <= -(1LL<<31) || phx >= (1LL<<31)
   || ply <= -(1LL<<31) || phy >= (1LL<<31))
     std::cerr << "YOUR OBJECT IS OUT OF BOUNDS; THIS IS BUGGY LOL\n";
  uint32_t lx = (uint32_t)(plx + (1LL<<31));
  uint32_t hx = (uint32_t)(phx + (1LL<<31));
  uint32_t ly = (uint32_t)(ply + (1LL<<31));
  uint32_t hy = (uint32_t)(phy + (1LL<<31));

  int needed_zbox_ignored_bits = 0;
  uint32_t split_x;
  uint32_t split_y;
  uint32_t size;
  while (true) {
    size = (1ULL<<needed_zbox_ignored_bits);
    split_x = (lx & (~(size - 1))) + size; // == (lx % size) + size
    if (split_x + size <= hx) { ++needed_zbox_ignored_bits; continue; }
    split_y = (ly & (~(size - 1))) + size; // == (ly % size) + size
    if (split_y + size <= hy) { ++needed_zbox_ignored_bits; continue; }
    break;
  }
  // This whole bounds-to-zboxes algorithm is shitty, unreadable code. Fix it sometime, OR AT LEAST WRITE EXTENSIVE COMMENTS. TODO TODO
  const bool xdim_covered = split_x > hx;
  const bool ydim_covered = split_y > hy;
  if (xdim_covered && ydim_covered) {
    // wheeeee
    callback(makeZBox(lx, ly, needed_zbox_ignored_bits * 2));
    return;
  }
  else if (xdim_covered && (split_y & size)) {
    // wheeeee
    callback(makeZBox(lx, ly, needed_zbox_ignored_bits * 2 + 1));
    return;
  }
  else if (split_y & size) {
    if (split_x & size) {
      // wheeeee
      callback(makeZBox(lx, ly, needed_zbox_ignored_bits * 2 + 2));
      return;
    }
    else {
      callback(makeZBox(lx, ly, needed_zbox_ignored_bits * 2 + 1));
      callback(makeZBox(hx, ly, needed_zbox_ignored_bits * 2 + 1));
      return;
    }
  }
  else if (xdim_covered) {
    callback(makeZBox(lx, ly, needed_zbox_ignored_bits * 2));
    callback(makeZBox(lx, hy, needed_zbox_ignored_bits * 2));
    return;
  }
  else if (ydim_covered) {
    callback(makeZBox(lx, ly, needed_zbox_ignored_bits * 2));
    callback(makeZBox(hx, ly, needed_zbox_ignored_bits * 2));
    return;
  }
  else {
    callback(makeZBox(lx, ly, 2*lowest_shift_atleast(std::max(split_x - lx, split_y - ly))));
    callback(makeZBox(lx, hy, 2*lowest_shift_atleast(std::max(split_x - lx, hy + 1 - split_y))));
    callback(makeZBox(hx, ly, 2*lowest_shift_atleast(std::max(hx + 1 - split_x, split_y - ly))));
    callback(makeZBox(hx, hy, 2*lowest_shift_atleast(std::max(hx + 1 - split_x, hy + 1 - split_y))));
    return;
  }
}

void insertAndGetOverlapsOfShape(ZTree::ZTree &tree, ObjectIndex idx, ExactGeom::Shape shape, std::set<std::pair<ObjectIndex, ObjectIndex> > &overlapsCollector) {
  generateZBoxes(shape, MaybeInsertMaybeGetCallback(&tree, idx, true, &overlapsCollector));
}

void insertShape(ZTree::ZTree &tree, ObjectIndex idx, ExactGeom::Shape shape) {
  generateZBoxes(shape, MaybeInsertMaybeGetCallback(&tree, idx, true, NULL));
}

void getOverlapsOfShape(ZTree::ZTree &tree, ObjectIndex idx, ExactGeom::Shape shape, std::set<std::pair<ObjectIndex, ObjectIndex> > &overlapsCollector) {
  generateZBoxes(shape, MaybeInsertMaybeGetCallback(&tree, idx, false, &overlapsCollector));
}

struct insertBoundsToVectorCallback {
  insertBoundsToVectorCallback(std::vector<ExactGeom::Bounds> *boundses):boundses(boundses){}
  std::vector<ExactGeom::Bounds> *boundses;
  void operator()(ZTree::ZBox box) {
    int64_t xExplicit = 0;
    int64_t yExplicit = 0;
    for (int i = 63; i >= box.num_low_bits_ignored; --i) {
      //if (box.bits & (1ULL << i)) std::cerr << "found bit " << i << "\n"; 
      int halfi = i / 2;
      if (i % 2) xExplicit |= (box.bits & (1ULL << i)) >> (i - halfi);
      else       yExplicit |= (box.bits & (1ULL << i)) >> (i - halfi);
    }
    xExplicit = xExplicit - (1LL<<31);
    yExplicit = yExplicit - (1LL<<31);
    xExplicit = xExplicit * ZFactor;
    yExplicit = yExplicit * ZFactor;
    int64_t xWidth = (1LL<<(box.num_low_bits_ignored / 2))*ZFactor - 1;
    int64_t yWidth = (1LL<<((box.num_low_bits_ignored + 1) / 2))*ZFactor - 1;
    //std::cerr << box.bits << " !! " << (int)box.num_low_bits_ignored << "; " << xExplicit << "," << yExplicit << "\n";
    boundses->push_back(ExactGeom::Bounds(true,
        xExplicit,
        xExplicit + xWidth,
        yExplicit,
        yExplicit + yWidth
      ));
  }
};

std::vector<ExactGeom::Bounds> shapeZBoxBoundses(ExactGeom::Shape shape) {
  std::vector<ExactGeom::Bounds> boundses;
  generateZBoxes(shape, insertBoundsToVectorCallback(&boundses));
  return boundses;
}




}

