/*

Copyright 2011 Eli Dupree

This file is part of Eli Dupree's currently-unnamed experimental Haskell game, ported to C++.

This game is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This game is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this game.  If not, see <http://www.gnu.org/licenses/>.

*/

#ifndef HASKELLTOCPPGAME_EXACTGEOM_HPP
#define HASKELLTOCPPGAME_EXACTGEOM_HPP

#include <vector>
#include <inttypes.h>

namespace ExactGeom {

struct Bounds {
  Bounds():is_anywhere(false){}
  Bounds(Bounds const& b):is_anywhere(b.is_anywhere),lx(b.lx),hx(b.hx),ly(b.ly),hy(b.hy){}
  Bounds(bool is_anywhere,int64_t lx,int64_t hx,int64_t ly,int64_t hy):is_anywhere(is_anywhere),lx(lx),hx(hx),ly(ly),hy(hy){}
  bool is_anywhere;
  int64_t lx, hx, ly, hy;
};

bool boundsOverlap(Bounds b1, Bounds b2);

struct Displacement
{
  Displacement():dx(0),dy(0){}
  Displacement(int64_t dx,int64_t dy):dx(dx),dy(dy){}
  int64_t dx, dy;
};

struct Point
{
  Point():x(0),y(0){}
  Point(int64_t x,int64_t y):x(x),y(y){}
  int64_t x, y;
  Point operator+(Displacement d)const { return Point(x+d.dx, y+d.dy); }
  void operator+=(Displacement d) { x+=d.dx; y+=d.dy; }
};

struct LineSegment
{
  LineSegment(){}
  LineSegment(Point e1, Point e2):e1(e1),e2(e2){}
  Point e1, e2;
};

struct Polygon
{
  Polygon(){} // be hella careful with these default-constructed buggers
  Polygon(std::vector<Point> points):points(points){}
  std::vector<Point> points;
};

struct Shape
{
  Shape():boundsCacheValid(false) {}
  Shape(Point init):boundsCacheValid(false) { points.push_back(init); }
  Shape(LineSegment init):boundsCacheValid(false) { segments.push_back(init); }
  Shape(Polygon init):boundsCacheValid(false) { polygons.push_back(init); }
  Shape(Shape const& other):points(other.points),segments(other.segments),polygons(other.polygons),boundsCache(other.boundsCache),boundsCacheValid(other.boundsCacheValid) {}
  void moveBy(Displacement d);
  Bounds bounds()const;
  Shape sweep(Displacement d)const;
  bool intersects(Shape const& other)const;

  std::vector<Point> const& getPoints()const { return points; }
  std::vector<LineSegment> const& getSegments()const { return segments; }
  std::vector<Polygon> const& getPolygons()const { return polygons; }
private:
  std::vector<Point> points;
  std::vector<LineSegment> segments;
  std::vector<Polygon> polygons;

  mutable Bounds boundsCache;
  mutable bool boundsCacheValid;
};

}

#endif

